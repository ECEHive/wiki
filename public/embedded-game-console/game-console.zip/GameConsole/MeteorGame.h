#pragma once
// Original Meteor Mayhem game, retained in a separate namespace.
namespace Meteor {
constexpr int W = 320;
constexpr int H = 240;
constexpr int HUD_H = 27;

constexpr uint32_t FRAME_MS = 33;
constexpr uint32_t FIRE_MS = 175;
constexpr uint32_t NOVA_MS = 7000;
constexpr uint32_t HOLD_MS = 700;
constexpr uint32_t DEBOUNCE_MS = 25;

constexpr int METEOR_COUNT = 12;
constexpr int BULLET_COUNT = 10;
constexpr int STAR_COUNT = 18;

Preferences prefs;

enum GameState {
  MENU,
  PLAYING,
  PAUSED,
  GAME_OVER
};

GameState state = MENU;

// =======================================
// GAME OBJECTS
// =======================================

struct Meteor {
  float x, y;
  float vx, vy;
  int radius;
  bool active;
};

struct Bullet {
  float x, y;
  bool active;
};

struct Star {
  float x, y;
  float speed;
};

struct Bonus {
  float x, y;
  bool active;
};

Meteor meteors[METEOR_COUNT];
Bullet bullets[BULLET_COUNT];
Star stars[STAR_COUNT];

Bonus bonus = {0, 0, false};

// =======================================
// DIFFICULTY
// =======================================

const char* MODE_NAMES[] = {
  "EASY", "NORMAL", "HARD"
};

const char* SCORE_KEYS[] = {
  "easy", "normal", "hard"
};

const int METEOR_SPEED[] = {78, 110, 150};
const int SPAWN_MS[] = {920, 640, 430};
const int START_LIVES[] = {4, 3, 2};

int difficulty = 1;
int bestScores[3] = {0, 0, 0};

// =======================================
// STATE VARIABLES
// =======================================

float shipX = W / 2.0f;
float shipY = H - 33.0f;


int score = 0;
int lives = 3;

uint32_t lastFrame = 0;
uint32_t lastSpawn = 0;
uint32_t lastBonus = 0;
uint32_t lastShot = 0;
uint32_t lastNova = 0;
uint32_t invulnerableUntil = 0;
uint32_t pauseStarted = 0;

int flashFrames = 0;
bool novaBorderDrawn = false;

// HUD caching
int drawnScore = -1;
int drawnLives = -1;
int drawnNova = -1;

// Menu input
int previousMenuDirection = 0;
uint32_t lastMenuMove = 0;

// Button debouncing
bool rawSwitchPrevious = false;
bool switchPressed = false;
bool longPressHandled = false;

uint32_t switchChangedAt = 0;
uint32_t switchPressedAt = 0;
GameState switchPressState = MENU;

// =======================================
// UTILITIES
// =======================================

float clampValue(float v, float low, float high) {
  if (v < low) return low;
  if (v > high) return high;
  return v;
}

bool collision(
  float ax, float ay,
  float bx, float by,
  float radius
) {
  float dx = ax - bx;
  float dy = ay - by;

  return dx * dx + dy * dy <= radius * radius;
}

// =======================================
// SPACESHIP
// =======================================

void drawShip(int x, int y) {
  tft.fillTriangle(
    x, y - 13,
    x - 12, y + 11,
    x + 12, y + 11,
    ST77XX_CYAN
  );

  tft.fillTriangle(
    x, y - 7,
    x - 5, y + 7,
    x + 5, y + 7,
    ST77XX_BLUE
  );

  tft.fillCircle(
    x, y + 2,
    3,
    ST77XX_WHITE
  );

  tft.fillTriangle(
    x - 4, y + 11,
    x, y + 19,
    x + 4, y + 11,
    ST77XX_YELLOW
  );
}

// =======================================
// MENU
// =======================================

void drawMenu() {
  tft.fillScreen(ST77XX_BLACK);

  centerText(
    "METEOR MAYHEM",
    23, 3, ST77XX_CYAN
  );

  centerText(
    "* SPACE SURVIVAL *",
    64, 1, ST77XX_YELLOW
  );

  drawShip(74, 112);

  tft.fillCircle(
    242, 108, 15,
    ST77XX_RED
  );

  tft.drawCircle(
    242, 108, 18,
    ST77XX_YELLOW
  );

  tft.setTextColor(ST77XX_WHITE);
  tft.setTextSize(2);

  tft.setCursor(62, 145);
  tft.print("MODE: ");
  tft.print(MODE_NAMES[difficulty]);

  tft.setTextSize(1);

  tft.setCursor(110, 168);
  tft.print("BEST: ");
  tft.print(bestScores[difficulty]);

  centerText(
    "LEFT/RIGHT: CHANGE DIFFICULTY",
    193, 1, ST77XX_GREEN
  );

  centerText(
    "PRESS JOYSTICK TO START",
    208, 1, ST77XX_WHITE
  );

  centerText(
    "AUTO FIRE | TAP NOVA | HOLD PAUSE",
    222, 1, ST77XX_WHITE
  );
}

void updateMenu(uint32_t now) {
  float axis = readAxis(JOY_X, centerX);

  int direction = 0;

  if (axis > 0.55f) direction = 1;
  if (axis < -0.55f) direction = -1;

  if (direction != 0 &&
      (direction != previousMenuDirection ||
       now - lastMenuMove >= 350)) {

    difficulty =
      (difficulty + direction + 3) % 3;

    lastMenuMove = now;

    beep(440, 25);
    drawMenu();
  }

  previousMenuDirection = direction;
}

// =======================================
// PAUSE AND GAME OVER
// =======================================

void drawPause() {
  tft.fillScreen(ST77XX_BLACK);

  centerText(
    "PAUSED",
    76, 4, ST77XX_YELLOW
  );

  centerText(
    "TAP: RESUME",
    143, 2, ST77XX_WHITE
  );
  centerText("HOLD: MAIN MENU", 177, 1, ST77XX_CYAN);
}

void drawGameOver() {
  tft.fillScreen(ST77XX_BLACK);

  centerText(
    "GAME OVER",
    28, 3, ST77XX_RED
  );

  tft.setTextColor(ST77XX_WHITE);
  tft.setTextSize(2);

  tft.setCursor(68, 93);
  tft.print("SCORE: ");
  tft.print(score);

  tft.setCursor(68, 124);
  tft.print("BEST:  ");
  tft.print(bestScores[difficulty]);

  centerText(
    "TAP: RETRY",
    185, 2, ST77XX_GREEN
  );

  centerText(
    "HOLD: MAIN MENU",
    215, 1, ST77XX_CYAN
  );
}

// =======================================
// HUD
// =======================================

void initializePlayfield() {
  tft.fillScreen(ST77XX_BLACK);

  tft.fillRect(
    0, 0,
    W, HUD_H,
    tft.color565(11, 20, 42)
  );

  tft.drawFastHLine(
    0, HUD_H - 1,
    W,
    ST77XX_BLUE
  );

  drawnScore = -1;
  drawnLives = -1;
  drawnNova = -1;
  novaBorderDrawn = false;
}

void updateHUD(uint32_t now) {
  uint16_t background =
    tft.color565(11, 20, 42);

  tft.setTextSize(2);

  char text[20];

  if (score != drawnScore) {
    tft.setTextColor(
      ST77XX_WHITE, background
    );

    snprintf(
      text, sizeof(text),
      "PTS:%-6d", score
    );

    tft.setCursor(5, 6);
    tft.print(text);

    drawnScore = score;
  }

  if (lives != drawnLives) {
    tft.setTextColor(
      ST77XX_WHITE, background
    );

    snprintf(
      text, sizeof(text),
      "HP:%-2d", lives
    );

    tft.setCursor(140, 6);
    tft.print(text);

    drawnLives = lives;
  }

  uint32_t elapsed = now - lastNova;

  int remaining = elapsed >= NOVA_MS
    ? 0
    : (NOVA_MS - elapsed + 999) / 1000;

  if (remaining != drawnNova) {
    tft.setTextColor(
      ST77XX_YELLOW, background
    );

    if (remaining == 0) {
      snprintf(
        text, sizeof(text),
        "N:READY"
      );
    } else {
      snprintf(
        text, sizeof(text),
        "N:%ds   ", remaining
      );
    }

    tft.setCursor(212, 6);
    tft.print(text);

    drawnNova = remaining;
  }
}

// =======================================
// LOW-FLICKER OBJECT ERASING
// =======================================

void eraseObjects() {
  // Erase previous NOVA visual
  if (novaBorderDrawn) {
    tft.drawRect(
      1, HUD_H + 1,
      W - 2, H - HUD_H - 2,
      ST77XX_BLACK
    );

    novaBorderDrawn = false;
  }

  for (int i = 0; i < STAR_COUNT; i++) {
    tft.drawPixel(
      (int)stars[i].x,
      (int)stars[i].y,
      ST77XX_BLACK
    );
  }

  for (int i = 0; i < METEOR_COUNT; i++) {
    if (!meteors[i].active) continue;

    tft.fillCircle(
      (int)meteors[i].x,
      (int)meteors[i].y,
      meteors[i].radius + 2,
      ST77XX_BLACK
    );
  }

  for (int i = 0; i < BULLET_COUNT; i++) {
    if (!bullets[i].active) continue;

    tft.fillRect(
      (int)bullets[i].x - 3,
      (int)bullets[i].y - 6,
      7, 12,
      ST77XX_BLACK
    );
  }

  if (bonus.active) {
    tft.fillRect(
      (int)bonus.x - 9,
      (int)bonus.y - 9,
      19, 19,
      ST77XX_BLACK
    );
  }

  tft.fillRect(
    (int)shipX - 14,
    (int)shipY - 15,
    29, 36,
    ST77XX_BLACK
  );
}

// =======================================
// DRAW GAME OBJECTS
// =======================================

void drawObjects(uint32_t now) {
  // Stars
  for (int i = 0; i < STAR_COUNT; i++) {
    tft.drawPixel(
      (int)stars[i].x,
      (int)stars[i].y,
      i % 3 == 0
        ? ST77XX_BLUE
        : ST77XX_WHITE
    );
  }

  // Bonus star
  if (bonus.active) {
    int x = bonus.x;
    int y = bonus.y;

    tft.drawFastHLine(
      x - 7, y,
      15, ST77XX_YELLOW
    );

    tft.drawFastVLine(
      x, y - 7,
      15, ST77XX_YELLOW
    );

    tft.fillCircle(
      x, y, 4,
      ST77XX_GREEN
    );
  }

  // Meteors
  for (int i = 0; i < METEOR_COUNT; i++) {
    if (!meteors[i].active) continue;

    int x = meteors[i].x;
    int y = meteors[i].y;
    int r = meteors[i].radius;

    tft.fillCircle(
      x, y, r,
      ST77XX_RED
    );

    tft.drawCircle(
      x, y, r,
      ST77XX_YELLOW
    );

    tft.fillCircle(
      x - r / 3,
      y - r / 4,
      r / 3,
      tft.color565(120, 20, 20)
    );
  }

  // Bullets
  for (int i = 0; i < BULLET_COUNT; i++) {
    if (!bullets[i].active) continue;

    tft.fillRoundRect(
      (int)bullets[i].x - 2,
      (int)bullets[i].y - 5,
      5, 10, 2,
      ST77XX_GREEN
    );
  }

  // Blink briefly when hit
  if ((int32_t)(now - invulnerableUntil) >= 0 ||
      (now / 90) % 2 == 0) {

    drawShip(
      (int)shipX,
      (int)shipY
    );
  }

  // NOVA effect
  if (flashFrames > 0) {
    tft.drawRect(
      1, HUD_H + 1,
      W - 2, H - HUD_H - 2,
      ST77XX_CYAN
    );

    novaBorderDrawn = true;
    flashFrames--;
  }

  updateHUD(now);
}

// =======================================
// SPAWN METEOR
// =======================================

void spawnMeteor() {
  for (int i = 0; i < METEOR_COUNT; i++) {
    Meteor& m = meteors[i];

    if (m.active) continue;

    m.radius = random(7, 14);

    m.x = random(
      m.radius + 2,
      W - m.radius - 2
    );

    m.y = HUD_H + m.radius + 3;
    m.vx = random(-22, 23);

    m.vy =
      METEOR_SPEED[difficulty] +
      random(-15, 33) +
      clampValue(score * 0.03f, 0, 90);

    m.active = true;
    return;
  }
}

// =======================================
// AUTOMATIC SHOOTING
// =======================================

void shoot(uint32_t now) {
  if (now - lastShot < FIRE_MS) {
    return;
  }

  for (int i = 0; i < BULLET_COUNT; i++) {
    if (bullets[i].active) continue;

    bullets[i] = {
      shipX,
      shipY - 18,
      true
    };

    lastShot = now;

    // No buzzer on automatic shots.
    // This keeps the game much quieter.
    return;
  }
}

// =======================================
// NOVA BLAST
// =======================================

void activateNova(uint32_t now) {
  if (now - lastNova < NOVA_MS) {
    return;
  }

  // Clear previous sprite positions first
  eraseObjects();

  lastNova = now;
  flashFrames = 7;

  for (int i = 0; i < METEOR_COUNT; i++) {
    if (meteors[i].active) {
      meteors[i].active = false;
      score += 5;
    }
  }

  // Redraw remaining objects immediately
  drawObjects(now);

  beep(320, 85);
}

// =======================================
// START / END GAME
// =======================================

void startGame() {
  uint32_t now = millis();

  for (int i = 0; i < METEOR_COUNT; i++) {
    meteors[i].active = false;
  }

  for (int i = 0; i < BULLET_COUNT; i++) {
    bullets[i].active = false;
  }

  for (int i = 0; i < STAR_COUNT; i++) {
    stars[i] = {
      (float)random(W),
      (float)random(HUD_H + 2, H),
      (float)random(15, 55)
    };
  }

  bonus.active = false;

  shipX = W / 2.0f;
  shipY = H - 33.0f;

  score = 0;
  lives = START_LIVES[difficulty];

  flashFrames = 0;

  lastFrame = now;
  lastSpawn = now - SPAWN_MS[difficulty] + 350;
  lastBonus = now;
  lastShot = now - FIRE_MS;
  lastNova = now - NOVA_MS;
  invulnerableUntil = now;

  state = PLAYING;

  initializePlayfield();
  drawObjects(now);

  beep(600, 45);
}

void endGame() {
  state = GAME_OVER;

  if (score > bestScores[difficulty]) {
    bestScores[difficulty] = score;

    prefs.putInt(
      SCORE_KEYS[difficulty],
      score
    );
  }

  drawGameOver();
  beep(190, 140);
}

// =======================================
// MAIN GAME UPDATE
// =======================================

void updateGame(uint32_t now) {
  if (now - lastFrame < FRAME_MS) {
    return;
  }

  // Erase previous positions
  eraseObjects();

  float dt =
    (now - lastFrame) / 1000.0f;

  dt = clampValue(dt, 0, 0.065f);
  lastFrame = now;

  // Joystick movement
  float dx =
    readAxis(JOY_X, centerX) *
    X_DIRECTION;

  float dy =
    readAxis(JOY_Y, centerY) *
    Y_DIRECTION;

  shipX = clampValue(
    shipX + dx * 190 * dt,
    15, W - 15
  );

  shipY = clampValue(
    shipY + dy * 190 * dt,
    HUD_H + 30,
    H - 22
  );

  // Automatically fire
  shoot(now);

  // Meteor spawning
  uint32_t interval =
    (uint32_t)clampValue(
      SPAWN_MS[difficulty] -
        score * 0.11f,
      230, 1100
    );

  if (now - lastSpawn >= interval) {
    spawnMeteor();
    lastSpawn = now;
  }

  // Move background stars
  for (int i = 0; i < STAR_COUNT; i++) {
    stars[i].y += stars[i].speed * dt;

    if (stars[i].y >= H) {
      stars[i].y = HUD_H + 2;
      stars[i].x = random(W);
    }
  }

  // Move bullets
  for (int i = 0; i < BULLET_COUNT; i++) {
    if (!bullets[i].active) continue;

    bullets[i].y -= 335 * dt;

    if (bullets[i].y < HUD_H + 8) {
      bullets[i].active = false;
    }
  }

  // Move meteors and check collisions
  for (int i = 0; i < METEOR_COUNT; i++) {
    Meteor& m = meteors[i];

    if (!m.active) continue;

    m.y += m.vy * dt;

    m.x = clampValue(
      m.x + m.vx * dt,
      m.radius + 2,
      W - m.radius - 2
    );

    if (m.y > H + m.radius) {
      m.active = false;
      continue;
    }

    // Bullet collision
    for (int b = 0; b < BULLET_COUNT; b++) {
      if (!bullets[b].active) continue;

      if (collision(
        bullets[b].x,
        bullets[b].y,
        m.x,
        m.y,
        m.radius + 4
      )) {
        bullets[b].active = false;
        m.active = false;

        score += 10;

        // Quieter hit sound
        beep(420, 14);
        break;
      }
    }

    if (!m.active) continue;

    // Ship collision
    if ((int32_t)(now - invulnerableUntil) >= 0 &&
        collision(
          shipX, shipY,
          m.x, m.y,
          m.radius + 10
        )) {

      m.active = false;
      lives--;

      invulnerableUntil = now + 1200;

      beep(180, 110);

      if (lives <= 0) {
        endGame();
        return;
      }
    }
  }

  // Spawn bonus star
  if (!bonus.active &&
      now - lastBonus > 6200) {

    bonus = {
      (float)random(16, W - 16),
      (float)(HUD_H + 15),
      true
    };

    lastBonus = now;
  }

  // Bonus movement and collision
  if (bonus.active) {
    bonus.y += 75 * dt;

    if (bonus.y > H + 10) {
      bonus.active = false;
    } else if (collision(
      shipX, shipY,
      bonus.x, bonus.y,
      16
    )) {
      bonus.active = false;
      score += 50;

      // Softer and much shorter bonus sound
      beep(560, 25);
    }
  }

  // Draw new positions
  drawObjects(now);
}

// =======================================
// PAUSE / RESUME
// =======================================

void pauseGame(uint32_t now) {
  if (state != PLAYING) return;

  pauseStarted = now;
  state = PAUSED;

  drawPause();
  beep(380, 45);
}

void resumeGame(uint32_t now) {
  if (state != PAUSED) return;

  uint32_t pausedFor =
    now - pauseStarted;

  // Freeze game timing while paused
  lastFrame = now;
  lastSpawn += pausedFor;
  lastBonus += pausedFor;
  lastShot += pausedFor;
  lastNova += pausedFor;
  invulnerableUntil += pausedFor;

  state = PLAYING;

  initializePlayfield();
  drawObjects(now);

  beep(600, 45);
}

// =======================================
// JOYSTICK BUTTON HANDLING
// =======================================

// Uses polling, edge detection, and debounce.
// Short press = action
// Long press = pause/menu

void handleJoystickButton(uint32_t now) {
  bool rawPressed =
    digitalRead(JOY_SW) == LOW;

  if (rawPressed != rawSwitchPrevious) {
    switchChangedAt = now;
  }

  rawSwitchPrevious = rawPressed;

  // Only accept stable transitions
  if (now - switchChangedAt >= DEBOUNCE_MS &&
      rawPressed != switchPressed) {

    switchPressed = rawPressed;

    if (switchPressed) {
      switchPressedAt = now;
      longPressHandled = false;
      switchPressState = state;
    } else {
      // Button released
      uint32_t heldFor =
        now - switchPressedAt;

      if (!longPressHandled &&
          heldFor >= DEBOUNCE_MS &&
          state == switchPressState) {

        switch (state) {
          case MENU:
            startGame();
            break;

          case PLAYING:
            activateNova(now);
            break;

          case PAUSED:
            resumeGame(now);
            break;

          case GAME_OVER:
            startGame();
            break;
        }
      }
    }
  }

  // Handle long press while held down
  if (switchPressed &&
      !longPressHandled &&
      now - switchPressedAt >= HOLD_MS) {

    if (state == PLAYING) {
      longPressHandled = true;
      pauseGame(now);
    } else if (state == PAUSED || state == GAME_OVER) {
      longPressHandled = true;
      state = MENU;
      ::returnToLauncher();
    }
  }
}


// Scores remain in the original Meteor Mayhem NVS namespace.
void initScores() {
  prefs.begin("meteorGame", false);
  for (int i = 0; i < 3; ++i) {
    bestScores[i] = prefs.getInt(SCORE_KEYS[i], 0);
  }
}

} // namespace Meteor
