/*
  SEVEN-GAME ESP32 CONSOLE
  Tetris, Meteor Mayhem, Pong, Flappy, Snake, 2048, Doom Mini

  Target: ESP32-C6 (Arduino-ESP32 3.x), ST7789 240x320 in landscape.
  Libraries: Adafruit GFX, Adafruit ST7789, Preferences (part of ESP32 core).

  LAUNCHER: UP/DOWN chooses game (wraps around), LEFT/RIGHT chooses
            EASY/NORMAL/HARD (except 2048), CLICK starts.
  ALL GAMES: HOLD joystick switch 700 ms to pause; TAP while paused resumes;
             HOLD while paused or game over returns to launcher.
             TAP on game over retries.
  PONG: UP/DOWN move paddle, TAP to serve; first to 7 points wins.
  FLAPPY: TAP or UP flaps.
  SNAKE: four directions steer, TAP pauses.
  2048: four directions slide, TAP undoes one move.
  DOOM MINI: UP/DOWN walks, LEFT/RIGHT turns, TAP fires.
  TETRIS and METEOR retain their original joystick controls.

  Power: TFT reset pin must be tied high when TFT_RST=-1. TFT backlight
  must be powered separately as appropriate for your display module.
*/

#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <Preferences.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

// ========================= WIRING =========================
constexpr int BUZZER = 11;
constexpr int TFT_CS = 4;
constexpr int TFT_DC = 5;
constexpr int TFT_SCLK = 7;
constexpr int TFT_MOSI = 6;
constexpr int TFT_RST = -1;
constexpr int JOY_X = 0;
constexpr int JOY_Y = 1;
constexpr int JOY_SW = 10;
constexpr int X_DIRECTION = 1;  // -1 if X reads backwards
constexpr int Y_DIRECTION = 1;  // -1 if Y reads backwards
constexpr int SCREEN_ROTATION = 1; // 1 or 3 (landscape)
constexpr int W_SCREEN = 320;

Adafruit_ST7789 tft(&SPI, TFT_CS, TFT_DC, TFT_RST);
int centerX = 2048, centerY = 2048;
bool soundActive = false;
uint32_t soundEndAt = 0;

void returnToLauncher();
void drawArcadeGameOver(const char* title, int score, int best);

enum ArcadePhase { ARCADE_PLAYING, ARCADE_PAUSED, ARCADE_GAME_OVER };
ArcadePhase arcadePhase = ARCADE_PLAYING;

float readAxis(int pin, int center) {
  int delta = analogRead(pin) - center;
  if (abs(delta) < 220) return 0.0f;
  float span = delta >= 0 ? (4095 - center) : center;
  if (span < 500) span = 500;
  return constrain(delta / span, -1.0f, 1.0f);
}
void beep(int hz, uint32_t duration) {
  ledcWriteTone(BUZZER, hz);
  ledcWrite(BUZZER, 24);
  soundEndAt = millis() + duration;
  soundActive = true;
}
void updateBeep(uint32_t now) {
  if (soundActive && (int32_t)(now - soundEndAt) >= 0) {
    ledcWriteTone(BUZZER, 0);
    soundActive = false;
  }
}
void centerText(const char* text, int y, int size, uint16_t color) {
  tft.setTextSize(size);
  tft.setTextColor(color);
  int x = (W_SCREEN - (int)strlen(text) * 6 * size) / 2;
  tft.setCursor(max(0, x), y);
  tft.print(text);
}

#include "BufferedGraphics.h"

// The original Tetris and Meteor code is intentionally preserved.
#include "TetrisGame.h"
#include "MeteorGame.h"

// New games share the launcher, display, buzzer, and button handler.
#include "PongGame.h"
#include "FlappyGame.h"
#include "SnakeGame.h"
#include "Game2048.h"
#include "DoomGame.h"

// ====================== GAME REGISTRY ======================
enum GameId {
  GAME_TETRIS,
  GAME_METEOR,
  GAME_PONG,
  GAME_FLAPPY,
  GAME_SNAKE,
  GAME_2048,
  GAME_DOOM
};
struct GameEntry {
  const char* name;
  const char* description;
  bool hasDifficulty;
};
const GameEntry GAMES[] = {
  {"TETRIS",         "Stack blocks / clear lines", true},
  {"METEOR MAYHEM",  "Dodge / shoot / survive",   true},
  {"PONG",           "Beat the CPU to 7 points",  true},
  {"FLAPPY BIRD",    "Fly through pipe gaps",    true},
  {"SNAKE",          "Eat food / avoid yourself", true},
  {"2048",           "Merge matching tiles",     false},
  {"DOOM MINI",      "Walk / turn / tap to fire", true}
};
constexpr int GAME_COUNT = sizeof(GAMES) / sizeof(GAMES[0]);
const char* const DIFFICULTY_NAMES[] = {"EASY", "NORMAL", "HARD"};
int selectedGame = GAME_TETRIS;
int menuDifficulty[GAME_COUNT] = {1, 1, 1, 1, 1, 0, 1};
bool launcherActive = true;
bool menuVerticalLatched = false;
int menuHorizontalDirection = 0;
uint32_t lastMenuHorizontalAt = 0;

// Launcher switch debounce (separate from the games).
bool menuButtonRawPrevious = false;
bool menuButtonStable = false;
bool menuButtonIgnoreUntilRelease = false;
uint32_t menuButtonChangedAt = 0;

// Shared switch debounce for the arcade games.
bool arcadeButtonRawPrevious = false;
bool arcadeButtonStable = false;
bool arcadeLongHandled = false;
bool arcadeButtonIgnoreUntilRelease = false;
uint32_t arcadeButtonChangedAt = 0;
uint32_t arcadeButtonPressedAt = 0;
ArcadePhase arcadePressPhase = ARCADE_PLAYING;

constexpr int MENU_ROW_Y = 55, MENU_ROW_HEIGHT = 18;
int displayedMenuGame = -1, displayedMenuDifficulty = -1;

void drawLauncherRow(int game) {
  const int rowY = MENU_ROW_Y + MENU_ROW_HEIGHT * game;
  const bool selected = game == selectedGame;
  gameFrame.fillRect(18, rowY - 1, 284, MENU_ROW_HEIGHT, 0x080F);
  if (selected) {
    gameFrame.fillRoundRect(18, rowY - 1, 284, MENU_ROW_HEIGHT, 4, 0x2352);
    gameFrame.drawRoundRect(18, rowY - 1, 284, MENU_ROW_HEIGHT, 4, ST77XX_CYAN);
  }
  gameFrame.setTextSize(2);
  gameFrame.setTextColor(selected ? ST77XX_YELLOW : 0xBDF7);
  gameFrame.setCursor(31, rowY);
  gameFrame.print(selected ? ">" : " ");
  gameFrame.print(GAMES[game].name);
}
void drawLauncherDetails() {
  gameFrame.fillRect(0, 188, 320, 26, 0x080F);
  frameCenterText(GAMES[selectedGame].description, 191, 1, ST77XX_WHITE);
  char text[36];
  if (GAMES[selectedGame].hasDifficulty)
    snprintf(text, sizeof(text), "MODE: %s", DIFFICULTY_NAMES[menuDifficulty[selectedGame]]);
  else
    snprintf(text, sizeof(text), "NO DIFFICULTY");
  frameCenterText(text, 204, 1, ST77XX_GREEN);
}
void drawLauncher(bool fullRedraw = true) {
  if (fullRedraw) {
    gameFrame.fillScreen(0x080F);
    frameCenterText("GAME CONSOLE", 7, 3, ST77XX_CYAN);
    frameCenterText("UP/DOWN: SELECT GAME", 40, 1, ST77XX_YELLOW);
    for (int i = 0; i < GAME_COUNT; ++i) drawLauncherRow(i);
    drawLauncherDetails();
    frameCenterText("LEFT/RIGHT: MODE   TAP: START", 217, 1, ST77XX_WHITE);
    frameCenterText("HOLD WHEN PAUSED: MAIN MENU", 230, 1, ST77XX_CYAN);
    presentGameFrame();
  } else {
    if (displayedMenuGame != selectedGame) {
      if (displayedMenuGame >= 0) {
        drawLauncherRow(displayedMenuGame);
        presentGameFrame(18, MENU_ROW_Y + MENU_ROW_HEIGHT * displayedMenuGame - 1,
                         284, MENU_ROW_HEIGHT);
      }
      drawLauncherRow(selectedGame);
      presentGameFrame(18, MENU_ROW_Y + MENU_ROW_HEIGHT * selectedGame - 1,
                       284, MENU_ROW_HEIGHT);
    }
    if (displayedMenuGame != selectedGame ||
        displayedMenuDifficulty != menuDifficulty[selectedGame]) {
      drawLauncherDetails();
      presentGameFrame(0, 188, 320, 26);
    }
  }
  displayedMenuGame = selectedGame;
  displayedMenuDifficulty = menuDifficulty[selectedGame];
}

void drawArcadePause() {
  tft.fillScreen(0x080F);
  centerText("PAUSED", 70, 4, ST77XX_YELLOW);
  centerText("TAP TO RESUME", 155, 2, ST77XX_WHITE);
  centerText("HOLD TO RETURN TO MENU", 195, 1, ST77XX_CYAN);
}
void drawArcadeGameOver(const char* title, int score, int best) {
  tft.fillScreen(0x080F);
  centerText("GAME OVER", 24, 3, ST77XX_RED);
  centerText(title, 75, 2, ST77XX_CYAN);
  char text[32];
  snprintf(text, sizeof(text), "SCORE: %d", score);
  centerText(text, 116, 2, ST77XX_WHITE);
  snprintf(text, sizeof(text), "BEST: %d", best);
  centerText(text, 143, 2, ST77XX_YELLOW);
  centerText("TAP: RETRY", 192, 2, ST77XX_GREEN);
  centerText("HOLD: MAIN MENU", 222, 1, ST77XX_CYAN);
}

void returnToLauncher() {
  if (selectedGame == GAME_2048) Game2048::saveBest();
  if (selectedGame == GAME_DOOM) Doom::saveBest();
  launcherActive = true;
  menuVerticalLatched = true; // require joystick to return to center
  menuHorizontalDirection = 0;
  menuButtonIgnoreUntilRelease = true;
  menuButtonRawPrevious = true;
  menuButtonStable = true;
  drawLauncher(); beep(520, 45);
}

void startArcadeGame() {
  arcadePhase = ARCADE_PLAYING;
  arcadeButtonIgnoreUntilRelease = true;
  arcadeButtonRawPrevious = true;
  arcadeButtonStable = true;
  arcadeLongHandled = false;
  switch (selectedGame) {
    case GAME_PONG: Pong::startGame(); break;
    case GAME_FLAPPY: Flappy::startGame(); break;
    case GAME_SNAKE: Snake::startGame(); break;
    case GAME_2048: Game2048::startGame(); break;
    case GAME_DOOM: Doom::startGame(); break;
    default: break;
  }
}
void launchSelectedGame() {
  launcherActive = false;
  switch (selectedGame) {
    case GAME_TETRIS:
      Tetris::difficulty = menuDifficulty[selectedGame];
      Tetris::startGame();
      break;
    case GAME_METEOR:
      Meteor::difficulty = menuDifficulty[selectedGame];
      Meteor::startGame();
      break;
    case GAME_PONG:
      Pong::difficulty = menuDifficulty[selectedGame]; startArcadeGame(); break;
    case GAME_FLAPPY:
      Flappy::difficulty = menuDifficulty[selectedGame]; startArcadeGame(); break;
    case GAME_SNAKE:
      Snake::difficulty = menuDifficulty[selectedGame]; startArcadeGame(); break;
    case GAME_2048:
      startArcadeGame(); break;
    case GAME_DOOM:
      Doom::difficulty = menuDifficulty[selectedGame]; startArcadeGame(); break;
  }
}

void updateLauncher(uint32_t now) {
  float x = readAxis(JOY_X, centerX) * X_DIRECTION;
  float y = readAxis(JOY_Y, centerY) * Y_DIRECTION;
  int vertical = y < -0.55f ? -1 : (y > 0.55f ? 1 : 0);
  if (vertical && !menuVerticalLatched) {
    selectedGame = (selectedGame + vertical + GAME_COUNT) % GAME_COUNT;
    menuVerticalLatched = true;
    drawLauncher(false); beep(550, 30);
  } else if (fabsf(y) < 0.28f) {
    menuVerticalLatched = false;
  }
  int horizontal = x > 0.55f ? 1 : (x < -0.55f ? -1 : 0);
  if (horizontal && GAMES[selectedGame].hasDifficulty &&
      (horizontal != menuHorizontalDirection || now - lastMenuHorizontalAt >= 350)) {
    int& level = menuDifficulty[selectedGame];
    level = (level + horizontal + 3) % 3;
    lastMenuHorizontalAt = now;
    drawLauncher(false); beep(440, 24);
  }
  menuHorizontalDirection = horizontal;

  bool pressed = (digitalRead(JOY_SW) == LOW);
  if (menuButtonIgnoreUntilRelease) {
    if (!pressed) {
      menuButtonIgnoreUntilRelease = false;
      menuButtonRawPrevious = false;
      menuButtonStable = false;
      menuButtonChangedAt = now;
    }
    return;
  }
  if (pressed != menuButtonRawPrevious) menuButtonChangedAt = now;
  menuButtonRawPrevious = pressed;
  if (now - menuButtonChangedAt >= 25 && pressed != menuButtonStable) {
    menuButtonStable = pressed;
    if (!pressed) launchSelectedGame();
  }
}

void pauseArcade() {
  if (arcadePhase != ARCADE_PLAYING) return;
  arcadePhase = ARCADE_PAUSED;
  drawArcadePause(); beep(380, 45);
}
void resumeArcade(uint32_t now) {
  if (arcadePhase != ARCADE_PAUSED) return;
  arcadePhase = ARCADE_PLAYING;
  switch (selectedGame) {
    case GAME_PONG: Pong::resume(now); break;
    case GAME_FLAPPY: Flappy::resume(now); break;
    case GAME_SNAKE: Snake::resume(now); break;
    case GAME_2048: Game2048::resume(now); break;
    case GAME_DOOM: Doom::resume(now); break;
    default: break;
  }
  beep(610, 35);
}
void tapArcade(uint32_t now) {
  if (arcadePhase == ARCADE_PAUSED) { resumeArcade(now); return; }
  if (arcadePhase == ARCADE_GAME_OVER) { startArcadeGame(); return; }
  switch (selectedGame) {
    case GAME_PONG: Pong::serve(); break;
    case GAME_FLAPPY: Flappy::flap(); break;
    case GAME_SNAKE: pauseArcade(); break;
    case GAME_2048: Game2048::undo(); break;
    case GAME_DOOM: Doom::fire(now); break;
    default: break;
  }
}
void handleArcadeButton(uint32_t now) {
  bool pressed = digitalRead(JOY_SW) == LOW;
  if (arcadeButtonIgnoreUntilRelease) {
    if (!pressed) {
      arcadeButtonIgnoreUntilRelease = false;
      arcadeButtonRawPrevious = false;
      arcadeButtonStable = false;
      arcadeButtonChangedAt = now;
    }
    return;
  }
  if (pressed != arcadeButtonRawPrevious) arcadeButtonChangedAt = now;
  arcadeButtonRawPrevious = pressed;
  if (now - arcadeButtonChangedAt >= 25 && pressed != arcadeButtonStable) {
    arcadeButtonStable = pressed;
    if (pressed) {
      arcadeButtonPressedAt = now;
      arcadeLongHandled = false;
      arcadePressPhase = arcadePhase;
    } else if (!arcadeLongHandled && arcadePhase == arcadePressPhase) {
      tapArcade(now);
    }
  }
  if (arcadeButtonStable && !arcadeLongHandled &&
      now - arcadeButtonPressedAt >= 700) {
    if (arcadePhase == ARCADE_PLAYING) {
      arcadeLongHandled = true;
      pauseArcade();
    } else if (arcadePhase == ARCADE_PAUSED || arcadePhase == ARCADE_GAME_OVER) {
      arcadeLongHandled = true;
      returnToLauncher();
    }
  }
}
void updateArcade(uint32_t now) {
  if (arcadePhase != ARCADE_PLAYING) return;
  switch (selectedGame) {
    case GAME_PONG: Pong::update(now); break;
    case GAME_FLAPPY: Flappy::update(now); break;
    case GAME_SNAKE: Snake::update(now); break;
    case GAME_2048: Game2048::update(now); break;
    case GAME_DOOM: Doom::update(now); break;
    default: break;
  }
}

void setup() {
  pinMode(JOY_SW, INPUT_PULLUP);
  pinMode(JOY_X, INPUT);
  pinMode(JOY_Y, INPUT);
  analogReadResolution(12);
  // Keep the stick centered during calibration!
  long totalX = 0, totalY = 0;
  for (int i = 0; i < 16; ++i) {
    totalX += analogRead(JOY_X);
    totalY += analogRead(JOY_Y);
    delay(2);
  }
  centerX = totalX / 16;
  centerY = totalY / 16;
  ledcAttach(BUZZER, 2000, 8);
  ledcWriteTone(BUZZER, 0);
  SPI.begin(TFT_SCLK, -1, TFT_MOSI, TFT_CS);
  tft.init(240, 320);
  tft.setRotation(SCREEN_ROTATION);
  if (!gameFrame.getBuffer()) {
    tft.fillScreen(ST77XX_BLACK);
    centerText("DISPLAY BUFFER FULL", 100, 2, ST77XX_RED);
    while (true) delay(1000);
  }
  randomSeed(micros());

  // Existing NVS namespace names are unchanged, preserving saved scores.
  Tetris::initScores();
  Meteor::initScores();
  Pong::initScores();
  Flappy::initScores();
  Snake::initScores();
  Game2048::initScores();
  Doom::initScores();
  drawLauncher();
}
void loop() {
  uint32_t now = millis();
  updateBeep(now);
  if (launcherActive) {
    updateLauncher(now);
    return;
  }
  if (selectedGame == GAME_TETRIS) {
    Tetris::updateButton(now);
    if (!launcherActive && Tetris::state == Tetris::PLAYING)
      Tetris::updatePlaying(now);
  } else if (selectedGame == GAME_METEOR) {
    Meteor::handleJoystickButton(now);
    if (!launcherActive && Meteor::state == Meteor::PLAYING)
      Meteor::updateGame(now);
  } else {
    handleArcadeButton(now);
    if (!launcherActive) updateArcade(now);
  }
}
