#pragma once
// Flappy Bird-style one-button flying game.
namespace Flappy {
Preferences prefs;
const char* const KEYS[3] = {"easy", "normal", "hard"};
int difficulty = 1;
int bestScores[3] = {0, 0, 0};
int score = 0;
constexpr int TOP = 29, FLOOR = 226, BIRD_X = 72, BIRD_R = 8;
constexpr int PIPE_W = 38, N_PIPES = 2;
struct Pipe { float x; int gapY; bool scored; };
Pipe pipes[N_PIPES];
float birdY = 110, velocity = 0;
uint32_t lastFrame = 0;
int displayedScore = -1;
bool upWasHeld = false;
bool started = false;

void initScores() {
  prefs.begin("flappyGame", false);
  for (int i = 0; i < 3; ++i) bestScores[i] = prefs.getInt(KEYS[i], 0);
}
int gapSize() { return difficulty == 0 ? 97 : (difficulty == 1 ? 79 : 67); }
int randomGap() {
  int gap = gapSize();
  return random(TOP + 19, FLOOR - gap - 20);
}
void drawHud() {
  gameFrame.fillRect(0, 0, 320, TOP, 0x0842);
  gameFrame.setTextSize(2); gameFrame.setTextColor(ST77XX_CYAN);
  gameFrame.setCursor(8, 6); gameFrame.print("FLAPPY");
  gameFrame.setCursor(244, 6); gameFrame.print(score);
  gameFrame.drawFastHLine(0, TOP - 1, 320, ST77XX_BLUE);
  displayedScore = score;
}
void drawPipe(const Pipe& p, uint16_t col) {
  int x = (int)p.x;
  int gap = gapSize();
  gameFrame.fillRect(x, TOP, PIPE_W, p.gapY - TOP, col);
  gameFrame.fillRect(x, p.gapY + gap, PIPE_W, FLOOR - (p.gapY + gap), col);
  if (col != ST77XX_BLACK) {
    gameFrame.drawRect(x, p.gapY - 6, PIPE_W, 6, ST77XX_YELLOW);
    gameFrame.drawRect(x, p.gapY + gap, PIPE_W, 6, ST77XX_YELLOW);
  }
}
void drawBird(uint16_t col) {
  gameFrame.fillCircle(BIRD_X, (int)birdY, BIRD_R, col);
  if (col != ST77XX_BLACK) {
    gameFrame.fillCircle(BIRD_X + 3, (int)birdY - 2, 2, ST77XX_BLACK);
    gameFrame.fillTriangle(BIRD_X + 6, (int)birdY, BIRD_X + 14, (int)birdY + 2,
                     BIRD_X + 6, (int)birdY + 5, ST77XX_RED);
  }
}
void drawPlayfield() {
  gameFrame.fillRect(0, TOP, 320, FLOOR - TOP, ST77XX_BLACK);
  for (int i = 0; i < N_PIPES; ++i) drawPipe(pipes[i], ST77XX_GREEN);
  drawBird(ST77XX_YELLOW);
  if (!started) frameCenterText("TAP TO FLAP", 118, 2, ST77XX_WHITE);
}
void drawAll() {
  gameFrame.fillScreen(ST77XX_BLACK);
  drawHud();
  gameFrame.fillRect(0, FLOOR, 320, 240 - FLOOR, 0x6320);
  drawPlayfield();
  presentGameFrame();
}
void startGame() {
  score = 0;
  birdY = 119; velocity = 0;
  started = false; upWasHeld = false;
  pipes[0] = {295.0f, randomGap(), false};
  pipes[1] = {490.0f, randomGap(), false};
  lastFrame = millis();
  drawAll(); beep(650, 45);
}
void flap() {
  if (arcadePhase != ARCADE_PLAYING) return;
  if (!started) {
    started = true;
    drawPlayfield();
    presentGameFrame(0, TOP, 320, FLOOR - TOP);
  }
  velocity = -167.0f;
  beep(720, 15);
}
void endGame() {
  if (score > bestScores[difficulty]) {
    bestScores[difficulty] = score;
    prefs.putInt(KEYS[difficulty], score);
  }
  arcadePhase = ARCADE_GAME_OVER;
  drawArcadeGameOver("FLAPPY", score, bestScores[difficulty]);
  beep(175, 140);
}
void resume(uint32_t now) {
  lastFrame = now;
  upWasHeld = true; // require center before another UP flap
  drawAll();
}
void update(uint32_t now) {
  // UP is an alternative to tapping the joystick button.
  bool up = readAxis(JOY_Y, centerY) * Y_DIRECTION < -0.55f;
  if (up && !upWasHeld) flap();
  upWasHeld = up;
  if (now - lastFrame < 33) return;
  float dt = (now - lastFrame) / 1000.0f;
  if (dt > 0.05f) dt = 0.05f;
  lastFrame = now;
  if (!started) return;
  velocity += 460.0f * dt;
  birdY += velocity * dt;
  const float speed = difficulty == 0 ? 80.0f : (difficulty == 1 ? 103.0f : 129.0f);
  for (int i = 0; i < N_PIPES; ++i) {
    Pipe& p = pipes[i];
    p.x -= speed * dt;
    if (!p.scored && p.x + PIPE_W < BIRD_X) {
      p.scored = true; ++score; beep(830, 20);
    }
    if (p.x + PIPE_W < -5) {
      float furthest = -1000.0f;
      for (int j = 0; j < N_PIPES; ++j)
        if (j != i && pipes[j].x > furthest) furthest = pipes[j].x;
      p.x = fmaxf(320.0f, furthest + 195.0f);
      p.gapY = randomGap();
      p.scored = false;
    }
    if (BIRD_X + BIRD_R > p.x && BIRD_X - BIRD_R < p.x + PIPE_W &&
        (birdY - BIRD_R < p.gapY || birdY + BIRD_R > p.gapY + gapSize())) {
      endGame(); return;
    }
  }
  if (birdY - BIRD_R <= TOP || birdY + BIRD_R >= FLOOR) { endGame(); return; }
  drawPlayfield();
  if (displayedScore != score) {
    drawHud();
    presentGameFrame(0, 0, 320, FLOOR);
  } else {
    presentGameFrame(0, TOP, 320, FLOOR - TOP);
  }
}
} // namespace Flappy
