#pragma once
// Original compact raycasting shooter: no Doom engine, WAD, or extra libraries.
namespace Doom {
Preferences prefs;
const char* const KEYS[3] = {"easy", "normal", "hard"};
int difficulty = 1, bestScores[3] = {};
int score = 0, health = 100, wave = 1, kills = 0;
constexpr int MAP_W = 12, MAP_H = 12, MAX_ENEMIES = 8;
constexpr int VIEW_TOP = 28, VIEW_BOTTOM = 212, VIEW_H = VIEW_BOTTOM - VIEW_TOP;
constexpr int HORIZON = VIEW_TOP + VIEW_H / 2, RAYS = 160;
constexpr float ANGLE_PI = 3.14159265358979323846f, PLANE = 0.66f;
constexpr uint32_t SHOT_INTERVAL = 260, FRAME_INTERVAL = 50;
const char WORLD[MAP_H][MAP_W + 1] = {
  "111111111111",
  "100000000001",
  "101101110101",
  "100100000001",
  "100100110001",
  "100000100001",
  "101100101101",
  "100000000001",
  "100110011001",
  "100000000001",
  "100000000001",
  "111111111111",
};
struct Enemy {
  float x, y;
  int hp;
  uint32_t lastAttackAt, hurtUntil;
};
Enemy enemies[MAX_ENEMIES];
int enemyCount = 0;
float playerX = 1.5f, playerY = 1.5f, angle = 0;
float wallDepth[RAYS];
uint8_t paths[MAP_H][MAP_W];
uint32_t lastFrame = 0, lastShotAt = 0, muzzleUntil = 0;
uint32_t painUntil = 0, bannerUntil = 0;

void initScores() {
  prefs.begin("doomMini", false);
  for (int i = 0; i < 3; ++i) bestScores[i] = prefs.getInt(KEYS[i], 0);
}
void saveBest() {
  if (score > bestScores[difficulty]) {
    bestScores[difficulty] = score;
    prefs.putInt(KEYS[difficulty], score);
  }
}
bool activeUntil(uint32_t now, uint32_t until) {
  return (int32_t)(now - until) < 0;
}
bool isWall(int x, int y) {
  return x < 0 || y < 0 || x >= MAP_W || y >= MAP_H || WORLD[y][x] != '0';
}
bool canStand(float x, float y, float radius) {
  return !isWall((int)floorf(x - radius), (int)floorf(y - radius)) &&
         !isWall((int)floorf(x + radius), (int)floorf(y - radius)) &&
         !isWall((int)floorf(x - radius), (int)floorf(y + radius)) &&
         !isWall((int)floorf(x + radius), (int)floorf(y + radius));
}
// Returns distance along the supplied ray (perpendicular depth for camera rays).
float castRay(float dx, float dy, int& side, float& wallU) {
  int mx = (int)floorf(playerX), my = (int)floorf(playerY);
  const float deltaX = fabsf(dx) < 0.00001f ? 1e6f : fabsf(1.0f / dx);
  const float deltaY = fabsf(dy) < 0.00001f ? 1e6f : fabsf(1.0f / dy);
  const int stepX = dx < 0 ? -1 : 1, stepY = dy < 0 ? -1 : 1;
  float nextX = (dx < 0 ? playerX - mx : mx + 1 - playerX) * deltaX;
  float nextY = (dy < 0 ? playerY - my : my + 1 - playerY) * deltaY;
  float distance = 1;
  side = 0;
  for (int step = 0; step < MAP_W + MAP_H + 2; ++step) {
    if (nextX < nextY) {
      distance = nextX; nextX += deltaX; mx += stepX; side = 0;
    } else {
      distance = nextY; nextY += deltaY; my += stepY; side = 1;
    }
    if (isWall(mx, my)) break;
  }
  wallU = side ? playerX + distance * dx : playerY + distance * dy;
  wallU -= floorf(wallU);
  return fmaxf(distance, 0.05f);
}
bool visible(float x, float y) {
  float dx = x - playerX, dy = y - playerY;
  float distance = sqrtf(dx * dx + dy * dy);
  if (distance < 0.05f) return true;
  int side; float wallU;
  return castRay(dx / distance, dy / distance, side, wallU) + 0.01f >= distance;
}
void buildPaths() {
  memset(paths, 255, sizeof(paths));
  uint8_t queue[MAP_W * MAP_H];
  int head = 0, tail = 0;
  int px = (int)playerX, py = (int)playerY;
  paths[py][px] = 0;
  queue[tail++] = py * MAP_W + px;
  const int ox[4] = {1, 0, -1, 0}, oy[4] = {0, 1, 0, -1};
  while (head < tail) {
    int cell = queue[head++], x = cell % MAP_W, y = cell / MAP_W;
    for (int d = 0; d < 4; ++d) {
      int nx = x + ox[d], ny = y + oy[d];
      if (isWall(nx, ny) || paths[ny][nx] != 255) continue;
      paths[ny][nx] = paths[y][x] + 1;
      queue[tail++] = ny * MAP_W + nx;
    }
  }
}
void spawnWave(uint32_t now) {
  const float spots[MAX_ENEMIES][2] = {
    {4.5f, 1.5f}, {8.5f, 7.5f}, {1.5f, 10.5f}, {10.5f, 8.5f},
    {5.5f, 9.5f}, {3.5f, 7.5f}, {7.5f, 3.5f}, {10.5f, 2.5f}
  };
  const int count = min(MAX_ENEMIES, 3 + wave);
  enemyCount = 0;
  // Fall back to other open cells if the player is near a usual spawn point.
  for (int candidate = 0; candidate < MAX_ENEMIES + MAP_W * MAP_H && enemyCount < count; ++candidate) {
    float x, y;
    if (candidate < MAX_ENEMIES) {
      x = spots[candidate][0]; y = spots[candidate][1];
    } else {
      int cell = candidate - MAX_ENEMIES;
      x = cell % MAP_W + 0.5f; y = cell / MAP_W + 0.5f;
    }
    if (!canStand(x, y, 0.18f)) continue;
    float dx = x - playerX, dy = y - playerY;
    if (dx * dx + dy * dy < 4.0f) continue;
    bool occupied = false;
    for (int j = 0; j < enemyCount; ++j)
      if (fabsf(enemies[j].x - x) < 0.3f && fabsf(enemies[j].y - y) < 0.3f) occupied = true;
    if (occupied) continue;
    enemies[enemyCount++] = {x, y, 1 + difficulty, now, now};
  }
  bannerUntil = now + 1200;
}
uint16_t shade(uint16_t color, float distance, int side) {
  int light = distance < 2 ? 15 : distance < 4 ? 12 : distance < 7 ? 9 : 6;
  if (side) light = max(3, light - 3);
  return (((((color >> 11) & 31) * light / 15) << 11) |
          ((((color >> 5) & 63) * light / 15) << 5) |
          ((color & 31) * light / 15));
}
void drawWalls(float facingX, float facingY) {
  gameFrame.fillRect(0, VIEW_TOP, 320, VIEW_H / 2, 0x18C4);
  for (int band = 0; band < VIEW_H / 2; band += 8)
    gameFrame.fillRect(0, HORIZON + band, 320, min(8, VIEW_BOTTOM - HORIZON - band),
                       band < 24 ? 0x18C3 : band < 56 ? 0x2945 : 0x39C7);
  for (int column = 0; column < RAYS; ++column) {
    float cameraX = (column + 0.5f) * 2 / RAYS - 1;
    float dx = facingX - facingY * PLANE * cameraX;
    float dy = facingY + facingX * PLANE * cameraX;
    int side; float wallU;
    float distance = castRay(dx, dy, side, wallU);
    wallDepth[column] = distance;
    int height = min(4096, (int)(VIEW_H / distance));
    int top = HORIZON - height / 2;
    uint16_t brick = shade(0xA248, distance, side);
    uint16_t mortar = shade(0x30C3, distance, side);
    for (int row = 0; row < 8; ++row) {
      int y0 = max(VIEW_TOP, top + row * height / 8);
      int y1 = min(VIEW_BOTTOM, top + (row + 1) * height / 8);
      if (y1 <= y0) continue;
      bool seam = (((int)(wallU * 16) + (row & 1) * 8) & 15) == 0;
      gameFrame.fillRect(column * 2, y0, 2, y1 - y0, seam ? mortar : brick);
      int line = top + row * height / 8;
      if (line >= VIEW_TOP && line < VIEW_BOTTOM)
        gameFrame.drawFastHLine(column * 2, line, 2, mortar);
    }
  }
}
// Procedural pixel-art demon; dots are transparent, not copied game assets.
const char DEMON[16][13] = {
  ".W........W.", ".WW......WW.", "..RRRRRRRR..", ".RRRRRRRRRR.",
  ".RRYYRRYYRR.", ".RRKKRRKKRR.", "..RRRRRRRR..", "..RWWWWWWR..",
  "...RRRRRR...", "..RRRRRRRR..", ".RRRRRRRRRR.", "RR.RRRRRR.RR",
  "RR.RRRRRR.RR", "...RR..RR...", "..RRR..RRR..", ".KKKK..KKKK."
};
void drawEnemies(float facingX, float facingY, uint32_t now) {
  int order[MAX_ENEMIES];
  float distances[MAX_ENEMIES];
  for (int i = 0; i < enemyCount; ++i) {
    order[i] = i;
    float dx = enemies[i].x - playerX, dy = enemies[i].y - playerY;
    distances[i] = dx * dx + dy * dy;
  }
  for (int i = 1; i < enemyCount; ++i) {
    int item = order[i], j = i;
    while (j > 0 && distances[order[j - 1]] < distances[item]) {
      order[j] = order[j - 1]; --j;
    }
    order[j] = item;
  }
  for (int i = 0; i < enemyCount; ++i) {
    const Enemy& enemy = enemies[order[i]];
    if (enemy.hp <= 0) continue;
    float dx = enemy.x - playerX, dy = enemy.y - playerY;
    float depth = dx * facingX + dy * facingY;
    if (depth < 0.15f) continue;
    float sideways = -dx * facingY + dy * facingX;
    int height = min(512, (int)(VIEW_H * 0.85f / depth));
    int width = max(1, height * 3 / 4);
    int center = (int)(160 + sideways / (depth * PLANE) * 160);
    int left = center - width / 2;
    int top = HORIZON + (int)(VIEW_H / (2 * depth)) - height;
    for (int x = max(0, left) & ~1; x < min(320, left + width); x += 2) {
      if (depth >= wallDepth[x / 2]) continue;
      int sx = constrain((x - left) * 12 / width, 0, 11);
      for (int row = 0; row < 16; ++row) {
        char pixel = DEMON[row][sx];
        if (pixel == '.') continue;
        int y0 = max(VIEW_TOP, top + row * height / 16);
        int y1 = min(VIEW_BOTTOM, top + (row + 1) * height / 16);
        if (y1 <= y0) continue;
        uint16_t color = pixel == 'W' ? 0xEF7D : pixel == 'Y' ? ST77XX_YELLOW :
                         pixel == 'K' ? 0x1000 : activeUntil(now, enemy.hurtUntil) ? ST77XX_WHITE : 0xE986;
        gameFrame.fillRect(x, y0, 2, y1 - y0, shade(color, depth, 0));
      }
    }
  }
}
void drawAll(uint32_t now) {
  float fx = cosf(angle), fy = sinf(angle);
  drawWalls(fx, fy);
  drawEnemies(fx, fy, now);
  // Weapon and reticle are drawn after the 3D view.
  gameFrame.fillRoundRect(140, 187, 40, 33, 4, 0x528A);
  gameFrame.fillRect(151, 172, 18, 29, 0x8410);
  gameFrame.fillRect(155, 172, 10, 6, 0x2104);
  if (activeUntil(now, muzzleUntil)) {
    gameFrame.fillTriangle(142, 170, 160, 143, 178, 170, ST77XX_YELLOW);
    gameFrame.fillTriangle(149, 170, 160, 153, 171, 170, ST77XX_WHITE);
  }
  gameFrame.drawFastHLine(154, HORIZON, 13, ST77XX_WHITE);
  gameFrame.drawFastVLine(160, HORIZON - 6, 13, ST77XX_WHITE);
  if (activeUntil(now, bannerUntil)) {
    char text[20]; snprintf(text, sizeof(text), "WAVE %d", wave);
    frameCenterText(text, 48, 2, ST77XX_YELLOW);
  }
  gameFrame.fillRect(0, 0, 320, VIEW_TOP, 0x080F);
  gameFrame.setTextSize(2); gameFrame.setTextColor(ST77XX_RED);
  gameFrame.setCursor(7, 6); gameFrame.print("DOOM MINI");
  gameFrame.setTextSize(1); gameFrame.setTextColor(ST77XX_WHITE);
  gameFrame.setCursor(154, 5); gameFrame.print("SCORE "); gameFrame.print(score);
  gameFrame.setCursor(154, 17); gameFrame.print("BEST  "); gameFrame.print(max(score, bestScores[difficulty]));
  gameFrame.fillRect(0, VIEW_BOTTOM, 320, 240 - VIEW_BOTTOM, 0x080F);
  char text[48]; snprintf(text, sizeof(text), "HP %d   WAVE %d   KILLS %d", health, wave, kills);
  frameCenterText(text, 216, 1, health > 25 ? ST77XX_GREEN : ST77XX_RED);
  frameCenterText("UP/DOWN: WALK  L/R: TURN  TAP: FIRE", 230, 1, ST77XX_WHITE);
  if (activeUntil(now, painUntil)) gameFrame.drawRect(0, VIEW_TOP, 320, VIEW_H, ST77XX_RED);
  presentGameFrame();
}
void startGame() {
  uint32_t now = millis();
  score = kills = 0; health = 100; wave = 1;
  playerX = playerY = 1.5f; angle = 0;
  lastFrame = now; lastShotAt = now - SHOT_INTERVAL;
  muzzleUntil = painUntil = now;
  spawnWave(now);
  drawAll(now); beep(440, 45);
}
void endGame() {
  saveBest();
  arcadePhase = ARCADE_GAME_OVER;
  drawArcadeGameOver("DOOM MINI", score, bestScores[difficulty]);
  beep(150, 140);
}
void fire(uint32_t now) {
  if (arcadePhase != ARCADE_PLAYING || now - lastShotAt < SHOT_INTERVAL) return;
  lastShotAt = now; muzzleUntil = now + 100;
  float fx = cosf(angle), fy = sinf(angle), nearest = 9;
  int target = -1;
  for (int i = 0; i < enemyCount; ++i) {
    const Enemy& enemy = enemies[i];
    if (enemy.hp <= 0) continue;
    float dx = enemy.x - playerX, dy = enemy.y - playerY;
    float forward = dx * fx + dy * fy, sideways = fabsf(-dx * fy + dy * fx);
    if (forward <= 0 || forward > 8 || forward >= nearest ||
        sideways > max(0.22f, forward * 0.10f) || !visible(enemy.x, enemy.y)) continue;
    target = i; nearest = forward;
  }
  if (target >= 0) {
    Enemy& enemy = enemies[target];
    enemy.hurtUntil = now + 120;
    if (--enemy.hp == 0) { score += 100; ++kills; }
    bool alive = false;
    for (int i = 0; i < enemyCount; ++i) if (enemies[i].hp > 0) alive = true;
    if (!alive) {
      score += 250 * wave; ++wave;
      health = min(100, health + 20);
      spawnWave(now); saveBest();
    }
  }
  // The shot already presents a complete frame; avoid drawing it again in loop().
  lastFrame = now;
  drawAll(now);
  beep(target >= 0 ? 110 : 80, 50);
}
void resume(uint32_t now) {
  lastFrame = now; lastShotAt = now - SHOT_INTERVAL;
  muzzleUntil = painUntil = now;
  for (int i = 0; i < enemyCount; ++i) enemies[i].lastAttackAt = now;
  drawAll(now);
}
void update(uint32_t now) {
  if (now - lastFrame < FRAME_INTERVAL) return;
  float dt = fminf(0.06f, (now - lastFrame) / 1000.0f);
  lastFrame = now;
  float turn = readAxis(JOY_X, centerX) * X_DIRECTION;
  float walk = -readAxis(JOY_Y, centerY) * Y_DIRECTION;
  angle += turn * 2.25f * dt;
  if (angle > ANGLE_PI) angle -= 2 * ANGLE_PI;
  if (angle < -ANGLE_PI) angle += 2 * ANGLE_PI;
  float nx = playerX + cosf(angle) * walk * 1.8f * dt;
  float ny = playerY + sinf(angle) * walk * 1.8f * dt;
  if (canStand(nx, playerY, 0.20f)) playerX = nx;
  if (canStand(playerX, ny, 0.20f)) playerY = ny;
  buildPaths();
  const int ox[4] = {1, 0, -1, 0}, oy[4] = {0, 1, 0, -1};
  for (int i = 0; i < enemyCount; ++i) {
    Enemy& enemy = enemies[i];
    if (enemy.hp <= 0) continue;
    float dx = playerX - enemy.x, dy = playerY - enemy.y;
    float distance = sqrtf(dx * dx + dy * dy);
    bool sight = visible(enemy.x, enemy.y);
    if (distance < 0.85f && sight) {
      if (now - enemy.lastAttackAt >= (uint32_t)(1400 - difficulty * 300)) {
        enemy.lastAttackAt = now;
        health = max(0, health - (8 + difficulty * 4));
        painUntil = now + 160;
        beep(180, 45);
        if (health == 0) { endGame(); return; }
      }
      continue;
    }
    float tx = playerX, ty = playerY;
    if (!sight) {
      int cx = (int)enemy.x, cy = (int)enemy.y;
      int best = paths[cy][cx];
      tx = cx + 0.5f; ty = cy + 0.5f;
      for (int d = 0; d < 4; ++d) {
        int x = cx + ox[d], y = cy + oy[d];
        if (!isWall(x, y) && paths[y][x] < best) {
          best = paths[y][x]; tx = x + 0.5f; ty = y + 0.5f;
        }
      }
    }
    dx = tx - enemy.x; dy = ty - enemy.y;
    float length = sqrtf(dx * dx + dy * dy);
    if (length < 0.01f) continue;
    float step = min(length, (0.55f + difficulty * 0.17f) * dt);
    nx = enemy.x + dx / length * step;
    ny = enemy.y + dy / length * step;
    if (canStand(nx, enemy.y, 0.18f)) enemy.x = nx;
    if (canStand(enemy.x, ny, 0.18f)) enemy.y = ny;
  }
  drawAll(now);
}
} // namespace Doom
