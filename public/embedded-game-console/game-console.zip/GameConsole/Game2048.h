#pragma once
// Four-by-four 2048; tap to undo one move.
namespace Game2048 {
Preferences prefs;
uint32_t grid[4][4] = {};
uint32_t snapshot[4][4] = {};
int score = 0, bestScore = 0, savedBest = 0, snapshotScore = 0;
bool canUndo = false;
bool movedLatch = false;
constexpr int TILE = 42, GAP = 7, START_X = 65, START_Y = 45;
uint32_t displayedGrid[4][4] = {};
int displayedScore = -1, displayedBest = -1;

void initScores() {
  prefs.begin("game2048", false);
  bestScore = prefs.getInt("best", 0);
  savedBest = bestScore;
}
void saveBest() {
  if (score > bestScore) bestScore = score;
  if (bestScore > savedBest) {
    prefs.putInt("best", bestScore);
    savedBest = bestScore;
  }
}
uint16_t tileColor(uint32_t n) {
  switch (n) {
    case 0: return 0x2945;
    case 2: return 0xEF7D;
    case 4: return 0xE6B8;
    case 8: return 0xFD20;
    case 16: return 0xFB60;
    case 32: return 0xF9A5;
    case 64: return 0xF800;
    case 128: return 0xFEE0;
    case 256: return 0xFF60;
    case 512: return 0xFFA0;
    case 1024: return 0x07FF;
    default: return 0x07E0;
  }
}
void drawTile(int r, int c) {
  int x = START_X + c * (TILE + GAP);
  int y = START_Y + r * (TILE + GAP);
  uint32_t n = grid[r][c];
  gameFrame.fillRoundRect(x, y, TILE, TILE, 5, tileColor(n));
  if (n) {
    char buf[12]; snprintf(buf, sizeof(buf), "%lu", (unsigned long)n);
    int len = strlen(buf);
    int size = len >= 5 ? 1 : 2;
    int width = len * 6 * size;
    gameFrame.setTextSize(size);
    gameFrame.setTextColor(n <= 4 ? ST77XX_BLACK : ST77XX_WHITE);
    gameFrame.setCursor(x + (TILE - width) / 2, y + (TILE - 8 * size) / 2);
    gameFrame.print(buf);
  }
}
void drawHud() {
  gameFrame.fillRect(0, 0, 320, START_Y, 0x10A4);
  gameFrame.setTextSize(2); gameFrame.setTextColor(ST77XX_CYAN);
  gameFrame.setCursor(10, 7); gameFrame.print("2048");
  gameFrame.setTextSize(1); gameFrame.setTextColor(ST77XX_WHITE);
  gameFrame.setCursor(106, 7); gameFrame.print("SCORE: "); gameFrame.print(score);
  gameFrame.setCursor(106, 21); gameFrame.print("BEST:  "); gameFrame.print(max(bestScore, score));
  gameFrame.setCursor(10, 28); gameFrame.print("TAP=UNDO");
  displayedScore = score;
  displayedBest = max(bestScore, score);
}
void drawAll() {
  gameFrame.fillScreen(0x10A4);
  drawHud();
  for (int r = 0; r < 4; ++r) for (int c = 0; c < 4; ++c) drawTile(r, c);
  memcpy(displayedGrid, grid, sizeof(grid));
  presentGameFrame();
}
void drawChanges() {
  if (displayedScore != score || displayedBest != max(bestScore, score)) {
    drawHud();
    presentGameFrame(0, 0, 320, START_Y);
  }
  for (int r = 0; r < 4; ++r) for (int c = 0; c < 4; ++c) {
    if (displayedGrid[r][c] == grid[r][c]) continue;
    // Clear and draw each changed tile in RAM, then transfer it once.
    drawTile(r, c);
    presentGameFrame(START_X + c * (TILE + GAP),
                     START_Y + r * (TILE + GAP), TILE, TILE);
    displayedGrid[r][c] = grid[r][c];
  }
}
void spawnTile() {
  int empties[16], count = 0;
  for (int r = 0; r < 4; ++r) for (int c = 0; c < 4; ++c)
    if (grid[r][c] == 0) empties[count++] = r * 4 + c;
  if (count == 0) return;
  int index = empties[random(count)];
  grid[index / 4][index % 4] = random(10) == 0 ? 4 : 2;
}
bool hasMove() {
  for (int r = 0; r < 4; ++r) for (int c = 0; c < 4; ++c) {
    if (!grid[r][c]) return true;
    if (c < 3 && grid[r][c] == grid[r][c + 1]) return true;
    if (r < 3 && grid[r][c] == grid[r + 1][c]) return true;
  }
  return false;
}
void startGame() {
  memset(grid, 0, sizeof(grid));
  score = 0; canUndo = false; movedLatch = true;
  spawnTile(); spawnTile();
  drawAll(); beep(630, 45);
}
void endGame() {
  saveBest();
  arcadePhase = ARCADE_GAME_OVER;
  drawArcadeGameOver("2048", score, bestScore);
  beep(185, 120);
}
void resume(uint32_t now) { (void)now; movedLatch = true; drawAll(); }
// Direction is 0=up, 1=right, 2=down, 3=left.
void move(int direction) {
  uint32_t result[4][4];
  memcpy(result, grid, sizeof(result));
  int earned = 0;
  for (int line = 0; line < 4; ++line) {
    uint32_t packed[4] = {0, 0, 0, 0};
    int count = 0;
    for (int p = 0; p < 4; ++p) {
      int r = direction == 0 ? p : direction == 2 ? 3 - p : line;
      int c = direction == 1 ? 3 - p : direction == 3 ? p : line;
      if (grid[r][c]) packed[count++] = grid[r][c];
    }
    uint32_t merged[4] = {0, 0, 0, 0};
    int output = 0;
    for (int i = 0; i < count; ++i) {
      if (i + 1 < count && packed[i] == packed[i + 1]) {
        merged[output] = packed[i] * 2;
        earned += (int)merged[output];
        ++i;
      } else {
        merged[output] = packed[i];
      }
      ++output;
    }
    for (int p = 0; p < 4; ++p) {
      int r = direction == 0 ? p : direction == 2 ? 3 - p : line;
      int c = direction == 1 ? 3 - p : direction == 3 ? p : line;
      result[r][c] = merged[p];
    }
  }
  if (memcmp(result, grid, sizeof(result)) == 0) return;
  memcpy(snapshot, grid, sizeof(grid)); snapshotScore = score; canUndo = true;
  memcpy(grid, result, sizeof(grid)); score += earned;
  if (score > bestScore) bestScore = score;
  spawnTile();
  drawChanges(); beep(earned ? 660 : 430, 20);
  if (!hasMove()) endGame();
}
void undo() {
  if (!canUndo) return;
  memcpy(grid, snapshot, sizeof(grid));
  score = snapshotScore; canUndo = false;
  drawChanges(); beep(310, 35);
}
void update(uint32_t now) {
  (void)now;
  float x = readAxis(JOY_X, centerX) * X_DIRECTION;
  float y = readAxis(JOY_Y, centerY) * Y_DIRECTION;
  if (fabsf(x) < 0.28f && fabsf(y) < 0.28f) {
    movedLatch = false;
    return;
  }
  if (movedLatch) return;
  int direction = -1;
  if (fabsf(y) >= fabsf(x) && fabsf(y) > 0.55f)
    direction = y < 0 ? 0 : 2;
  else if (fabsf(x) > 0.55f)
    direction = x > 0 ? 1 : 3;
  if (direction >= 0) { movedLatch = true; move(direction); }
}
} // namespace Game2048
