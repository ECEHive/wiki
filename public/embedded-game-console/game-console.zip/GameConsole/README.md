# Seven-game ESP32 console

Open `GameConsole.ino` in Arduino IDE. Keep `TetrisGame.h`, `MeteorGame.h`,
`PongGame.h`, `FlappyGame.h`, `SnakeGame.h`, `Game2048.h`, `DoomGame.h`, and
`BufferedGraphics.h` in this same folder.
See the archive's top-level README for libraries, board setup, and GPIO wiring.

## Controls

| Context | Controls |
| --- | --- |
| Launcher | Up/down: select game. Left/right: difficulty where available. Press: start. |
| Playing | Hold joystick switch 700 ms: pause. |
| Paused | Tap: resume. Hold: return to launcher. |
| Game over | Tap: retry. Hold: return to launcher. |
| Tetris | Left/right: move. Up: rotate. Down: soft drop. Tap: hard drop. |
| Meteor Mayhem | Move in four directions. Auto-shoot. Tap: NOVA blast. |
| Pong | Up/down: move paddle. Tap: serve. First to 7 wins. |
| Flappy Bird | Tap or push up: flap. |
| Snake | Four directions: steer. Tap: pause. |
| 2048 | Four directions: slide/merge. Tap: undo the previous successful move once. |
| Doom Mini | Up/down: walk forward/back. Left/right: turn. Tap: fire. |

## Scores and difficulty

Tetris, Meteor Mayhem, Pong, Flappy Bird, Snake, and Doom Mini have Easy, Normal, and Hard
modes, each with its own best score. 2048 has no difficulty setting and one best
score. Scores persist using the ESP32 core's Preferences library. In Pong, the
best score is the most points scored in a match (up to 7).

## Doom Mini

Choose DOOM MINI from the launcher. This compact Doom-style shooter is included
in `DoomGame.h`; no extra libraries or game-data files are required. Walk the
maze, turn to aim, and tap to shoot. Walls block shots. Clear all enemies to
advance a wave, earn bonus points, and recover 20 health. Kills earn 100 points;
wave bonuses are 250 times the cleared wave number. Ammunition is unlimited,
with a short firing cooldown. Each difficulty changes enemy health, speed,
damage, and attack rate. Hold to pause; tap to resume; hold again to leave.
