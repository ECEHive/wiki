#pragma once

// One shared RGB565 frame (150 KiB), reused by the launcher and buffered games.
// Compose in RAM so the panel never shows an erase pass or half-drawn text.
GFXcanvas16 gameFrame(320, 240);

void presentGameFrame(int x = 0, int y = 0, int width = 320, int height = 240) {
  if (!gameFrame.getBuffer()) return;
  const int right = min(320, x + width);
  const int bottom = min(240, y + height);
  x = max(0, x);
  y = max(0, y);
  width = right - x;
  height = bottom - y;
  if (width <= 0 || height <= 0) return;

  tft.startWrite();
  tft.setAddrWindow(x, y, width, height);
  if (x == 0 && width == 320) {
    tft.writePixels(gameFrame.getBuffer() + y * 320, width * height);
  } else {
    for (int row = y; row < bottom; ++row)
      tft.writePixels(gameFrame.getBuffer() + row * 320 + x, width);
  }
  tft.endWrite();
}

void frameCenterText(const char* text, int y, int size, uint16_t color) {
  gameFrame.setTextSize(size);
  gameFrame.setTextColor(color);
  gameFrame.setCursor(max(0, (320 - (int)strlen(text) * 6 * size) / 2), y);
  gameFrame.print(text);
}
