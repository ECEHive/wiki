#pragma once
// Classic grid-based Snake.
namespace Snake {
Preferences prefs;
const char* const KEYS[3] = {"easy", "normal", "hard"};
int difficulty = 1;
int bestScores[3] = {0, 0, 0};
constexpr int COLS = 24, ROWS = 16, CELL = 12, BOARD_X = 16, BOARD_Y = 36;
constexpr int CAP = COLS * ROWS;
uint8_t sx[CAP], sy[CAP];
int length = 4, dx = 1, dy = 0, nextDx = 1, nextDy = 0;
int foodX = 0, foodY = 0, score = 0;
uint32_t lastMove = 0;
bool inputReady = true;

void initScores() {
  prefs.begin("snakeGame", false);
  for (int i = 0; i < 3; ++i) bestScores[i] = prefs.getInt(KEYS[i], 0);
}
void drawCell(int x, int y, uint16_t color) {
  tft.fillRect(BOARD_X + x * CELL + 1, BOARD_Y + y * CELL + 1,
               CELL - 2, CELL - 2, color);
}
void drawHud() {
  tft.fillRect(0, 0, 320, 30, 0x0842);
  tft.setTextSize(2); tft.setTextColor(ST77XX_CYAN);
  tft.setCursor(9, 7); tft.print("SNAKE");
  tft.setCursor(204, 7); tft.print("PTS:"); tft.print(score);
  tft.drawFastHLine(0, 29, 320, ST77XX_BLUE);
}
void placeFood() {
  if (length >= CAP) return;
  for (int tries = 0; tries < CAP * 2; ++tries) {
    int x = random(COLS), y = random(ROWS);
    bool occupied = false;
    for (int j = 0; j < length; ++j) {
      if (sx[j] == x && sy[j] == y) { occupied = true; break; }
    }
    if (!occupied) { foodX = x; foodY = y; return; }
  }
  // Deterministic fallback if almost every square is occupied.
  for (int y = 0; y < ROWS; ++y) for (int x = 0; x < COLS; ++x) {
    bool occupied = false;
    for (int j = 0; j < length; ++j)
      if (sx[j] == x && sy[j] == y) occupied = true;
    if (!occupied) { foodX = x; foodY = y; return; }
  }
}
void drawAll() {
  tft.fillScreen(ST77XX_BLACK); drawHud();
  tft.fillRect(BOARD_X, BOARD_Y, COLS * CELL, ROWS * CELL, 0x10A4);
  tft.drawRect(BOARD_X - 2, BOARD_Y - 2, COLS * CELL + 4,
               ROWS * CELL + 4, ST77XX_CYAN);
  for (int i = length - 1; i >= 0; --i)
    drawCell(sx[i], sy[i], i == 0 ? ST77XX_YELLOW : ST77XX_GREEN);
  drawCell(foodX, foodY, ST77XX_RED);
}
void startGame() {
  score = 0; length = 4;
  dx = 1; dy = 0; nextDx = 1; nextDy = 0; inputReady = true;
  for (int i = 0; i < length; ++i) {
    sx[i] = COLS / 2 - i; sy[i] = ROWS / 2;
  }
  placeFood(); lastMove = millis();
  drawAll(); beep(610, 40);
}
void endGame() {
  if (score > bestScores[difficulty]) {
    bestScores[difficulty] = score;
    prefs.putInt(KEYS[difficulty], score);
  }
  arcadePhase = ARCADE_GAME_OVER;
  drawArcadeGameOver("SNAKE", score, bestScores[difficulty]);
  beep(180, 140);
}
void resume(uint32_t now) {
  lastMove = now; inputReady = false;
  drawAll();
}
void update(uint32_t now) {
  float x = readAxis(JOY_X, centerX) * X_DIRECTION;
  float y = readAxis(JOY_Y, centerY) * Y_DIRECTION;
  int ax = (x > 0.55f ? 1 : x < -0.55f ? -1 : 0);
  int ay = (y > 0.55f ? 1 : y < -0.55f ? -1 : 0);
  if (ax == 0 && ay == 0) inputReady = true;
  if (inputReady && (ax || ay)) {
    // Prioritize the stronger analog axis if stick moves diagonally.
    if (fabsf(x) >= fabsf(y)) { ay = 0; }
    else { ax = 0; }
    if (!((ax == -dx && ay == -dy) || (ax == 0 && ay == 0))) {
      nextDx = ax; nextDy = ay;
      inputReady = false;
    }
  }
  int interval = difficulty == 0 ? 200 : difficulty == 1 ? 143 : 100;
  interval -= score / 40 * 4;
  if (interval < 57) interval = 57;
  if (now - lastMove < (uint32_t)interval) return;
  lastMove = now;
  dx = nextDx; dy = nextDy;
  int hx = (int)sx[0] + dx, hy = (int)sy[0] + dy;
  bool eats = (hx == foodX && hy == foodY);
  if (hx < 0 || hx >= COLS || hy < 0 || hy >= ROWS) { endGame(); return; }
  int occupiedCount = eats ? length : length - 1;
  for (int j = 0; j < occupiedCount; ++j) {
    if (sx[j] == hx && sy[j] == hy) { endGame(); return; }
  }
  int oldTailX = sx[length - 1], oldTailY = sy[length - 1];
  if (eats && length < CAP) ++length;
  for (int j = length - 1; j > 0; --j) {
    sx[j] = sx[j - 1]; sy[j] = sy[j - 1];
  }
  sx[0] = hx; sy[0] = hy;
  if (!eats) drawCell(oldTailX, oldTailY, 0x10A4);
  drawCell(sx[1], sy[1], ST77XX_GREEN);
  drawCell(hx, hy, ST77XX_YELLOW);
  if (eats) {
    score += 10;
    if (length >= CAP) { endGame(); return; }
    placeFood(); drawCell(foodX, foodY, ST77XX_RED);
    drawHud(); beep(700, 25);
  }
}
} // namespace Snake
