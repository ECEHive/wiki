#pragma once
// Original Tetris game, retained in a separate namespace.
namespace Tetris {
/* CONSTANTS */
Preferences prefs;

constexpr int SCREEN_W = 320;
constexpr int SCREEN_H = 240;
constexpr int COLS = 10;
constexpr int ROWS = 20;
constexpr int CELL = 10;
constexpr int BOARD_X = 42;
constexpr int BOARD_Y = 20;

constexpr uint16_t BG = 0x080F;
constexpr uint16_t BOARD_BG = 0x10A4;
constexpr uint16_t GRID_COLOR = 0x2148;
constexpr uint16_t TEXT = ST77XX_WHITE;
constexpr uint16_t COLORS[7] = {
  ST77XX_CYAN, ST77XX_YELLOW, ST77XX_MAGENTA,
  ST77XX_GREEN, ST77XX_RED, ST77XX_BLUE, 0xFD20
};

const char *MODE_NAMES[3] = {"EASY", "NORMAL", "HARD"};
const char *BEST_KEYS[3] = {"easy", "normal", "hard"};
const int BASE_FALL_MS[3] = {900, 650, 450};

// each piece is a 4x4 pattern. Rotations are calculated from this.
// order: I, O, T, S, Z, J, L
const char *const SHAPES[7][4] = {
  {"....", "XXXX", "....", "...."},
  {".XX.", ".XX.", "....", "...."},
  {".X..", "XXX.", "....", "...."},
  {".XX.", "XX..", "....", "...."},
  {"XX..", ".XX.", "....", "...."},
  {"X...", "XXX.", "....", "...."},
  {"..X.", "XXX.", "....", "...."}
};

/* GAME OBJECTS */
enum GameState { MENU, PLAYING, PAUSED, GAME_OVER };
GameState state = MENU;

struct Piece {
  int type;
  int rotation;
  int x;
  int y;
};
Piece current = {0, 0, 3, -1};
uint8_t board[ROWS][COLS];     // 0 = empty, 1-7 = each piece 
uint8_t lastDrawn[ROWS][COLS]; // cache to reduce flicker

int bag[7];
int bagIndex = 7;
int nextType = 0;
int shownNextType = -1;

int difficulty = 1;
int score = 0;
int lines = 0;
int level = 1;
int bestScores[3] = {0, 0, 0};
int shownScore = -1;
int shownLines = -1;
int shownLevel = -1;

int lastMenuDirection = 0;
int horizontalDirection = 0;
bool upLatched = false;
uint32_t nextHorizontalAt = 0;
uint32_t lastMenuMoveAt = 0;
uint32_t lastGravityAt = 0;
uint32_t lastSoftDropAt = 0;
uint32_t lastDrawAt = 0;

bool previousRawButton = false;
bool stableButtonPressed = false;
bool longPressHandled = false;
uint32_t buttonChangedAt = 0;
uint32_t buttonPressedAt = 0;
GameState stateAtButtonPress = MENU;

/* GAME LOGIC */
bool pieceCell(int type, int rotation, int col, int row) {
  // Keep O (square) stationary when rotating.
  if (type == 1) rotation = 0;

  int sourceX, sourceY;
  switch (rotation & 3) {
    case 0: sourceX = col;     sourceY = row;     break;
    case 1: sourceX = row;     sourceY = 3 - col; break;
    case 2: sourceX = 3 - col; sourceY = 3 - row; break;
    default: sourceX = 3 - row; sourceY = col;    break;
  }
  return SHAPES[type][sourceY][sourceX] == 'X';
}

bool canPlace(int type, int rotation, int x, int y) {
  for (int r = 0; r < 4; ++r) {
    for (int c = 0; c < 4; ++c) {
      if (!pieceCell(type, rotation, c, r)) continue;
      int bx = x + c;
      int by = y + r;
      if (bx < 0 || bx >= COLS || by >= ROWS) return false;
      if (by >= 0 && board[by][bx]) return false;
    }
  }
  return true;
}

void refillBag() {
  for (int i = 0; i < 7; ++i) bag[i] = i;
  for (int i = 6; i > 0; --i) {
    int j = random(i + 1);
    int temp = bag[i]; bag[i] = bag[j]; bag[j] = temp;
  }
  bagIndex = 0;
}

int takeFromBag() {
  if (bagIndex >= 7) refillBag();
  return bag[bagIndex++];
}

/* GRAPHICS */
void drawCell(int col, int row, uint8_t visual) {
  int x = BOARD_X + col * CELL;
  int y = BOARD_Y + row * CELL;
  tft.fillRect(x, y, CELL, CELL, BOARD_BG);

  if (visual >= 1 && visual <= 7) {
    uint16_t color = COLORS[visual - 1];
    tft.fillRect(x + 1, y + 1, CELL - 2, CELL - 2, color);
    tft.drawFastHLine(x + 2, y + 1, CELL - 4, ST77XX_WHITE);
  } else if (visual >= 8 && visual <= 14) {
    // draw landing preview piece
    tft.drawRect(x + 1, y + 1, CELL - 2, CELL - 2,
                 COLORS[visual - 8]);
  } else {
    tft.drawRect(x, y, CELL, CELL, GRID_COLOR);
  }
}

void drawNextPiece() {
  if (nextType == shownNextType) return;
  shownNextType = nextType;
  tft.fillRect(187, 166, 112, 53, BG);
  for (int r = 0; r < 4; ++r) {
    for (int c = 0; c < 4; ++c) {
      if (pieceCell(nextType, 0, c, r)) {
        int x = 211 + 12 * c;
        int y = 167 + 12 * r;
        tft.fillRect(x, y, 11, 11, COLORS[nextType]);
        tft.drawRect(x, y, 11, 11, ST77XX_WHITE);
      }
    }
  }
}

void drawStats() {
  if (score != shownScore) {
    tft.fillRect(171, 80, 145, 23, BG);
    tft.setTextColor(TEXT);
    tft.setTextSize(2);
    tft.setCursor(174, 82);
    tft.print(score);
    shownScore = score;
  }
  if (lines != shownLines) {
    tft.fillRect(171, 126, 74, 21, BG);
    tft.setTextColor(TEXT);
    tft.setTextSize(2);
    tft.setCursor(174, 128);
    tft.print(lines);
    shownLines = lines;
  }
  if (level != shownLevel) {
    tft.fillRect(249, 126, 67, 21, BG);
    tft.setTextColor(TEXT);
    tft.setTextSize(2);
    tft.setCursor(252, 128);
    tft.print(level);
    shownLevel = level;
  }
}

void drawGameScreen() {
  tft.fillScreen(BG);
  tft.drawRect(BOARD_X - 2, BOARD_Y - 2,
               COLS * CELL + 4, ROWS * CELL + 4, ST77XX_CYAN);
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_CYAN);
  tft.setCursor(174, 13);
  tft.print("TETRIS");
  tft.drawFastHLine(170, 37, 137, ST77XX_BLUE);
  tft.setTextSize(1);
  tft.setTextColor(ST77XX_YELLOW);
  tft.setCursor(174, 46);
  tft.print(MODE_NAMES[difficulty]);
  tft.setTextColor(0xAD7F);
  tft.setCursor(174, 67);  tft.print("SCORE");
  tft.setCursor(174, 112); tft.print("LINES");
  tft.setCursor(252, 112); tft.print("LEVEL");
  tft.setCursor(174, 154); tft.print("NEXT");
  tft.setCursor(174, 227); tft.print("BEST:");
  tft.setTextColor(TEXT);
  tft.print(bestScores[difficulty]);

  memset(lastDrawn, 255, sizeof(lastDrawn));
  shownScore = shownLines = shownLevel = -1;
  shownNextType = -1;
  drawStats();
  drawNextPiece();
}

void renderBoard() {
  uint8_t visual[ROWS][COLS];
  memcpy(visual, board, sizeof(visual));

  int ghostY = current.y;
  while (canPlace(current.type, current.rotation, current.x, ghostY + 1)) {
    ++ghostY;
  }

  for (int r = 0; r < 4; ++r) {
    for (int c = 0; c < 4; ++c) {
      if (!pieceCell(current.type, current.rotation, c, r)) continue;
      int x = current.x + c;
      int y = ghostY + r;
      if (x >= 0 && x < COLS && y >= 0 && y < ROWS && !visual[y][x]) {
        visual[y][x] = 8 + current.type;
      }
    }
  }

  for (int r = 0; r < 4; ++r) {
    for (int c = 0; c < 4; ++c) {
      if (!pieceCell(current.type, current.rotation, c, r)) continue;
      int x = current.x + c;
      int y = current.y + r;
      if (x >= 0 && x < COLS && y >= 0 && y < ROWS) {
        visual[y][x] = 1 + current.type;
      }
    }
  }

  for (int r = 0; r < ROWS; ++r) {
    for (int c = 0; c < COLS; ++c) {
      if (visual[r][c] != lastDrawn[r][c]) {
        drawCell(c, r, visual[r][c]);
        lastDrawn[r][c] = visual[r][c];
      }
    }
  }
  drawStats();
  drawNextPiece();
}

void drawMenu() {
  tft.fillScreen(BG);
  centerText("TETRIS", 29, 4, ST77XX_CYAN);
  centerText("* BLOCK STACKING GAME *", 86, 1, ST77XX_YELLOW);
  char mode[28];
  snprintf(mode, sizeof(mode), "MODE: %s", MODE_NAMES[difficulty]);
  centerText(mode, 126, 2, ST77XX_GREEN);
  centerText("LEFT / RIGHT: SELECT MODE", 159, 1, TEXT);
  centerText("PRESS JOYSTICK TO START", 177, 1, TEXT);
  centerText("MOVE: LEFT/RIGHT  ROTATE: UP", 198, 1, 0xAD7F);
  centerText("DOWN: SOFT DROP  TAP: HARD DROP", 211, 1, 0xAD7F);
  centerText("HOLD BUTTON: PAUSE", 224, 1, 0xAD7F);
}

void drawPause() {
  tft.fillScreen(BG);
  centerText("PAUSED", 77, 4, ST77XX_YELLOW);
  centerText("TAP: RESUME", 143, 2, TEXT);
  centerText("HOLD: MAIN MENU", 178, 1, ST77XX_CYAN);
}

void drawGameOver() {
  tft.fillScreen(BG);
  centerText("GAME OVER", 29, 3, ST77XX_RED);
  char s[30];
  snprintf(s, sizeof(s), "SCORE: %d", score);
  centerText(s, 92, 2, TEXT);
  snprintf(s, sizeof(s), "BEST: %d", bestScores[difficulty]);
  centerText(s, 122, 2, ST77XX_YELLOW);
  centerText("TAP: RETRY", 183, 2, ST77XX_GREEN);
  centerText("HOLD: MAIN MENU", 217, 1, ST77XX_CYAN);
}

/* GAME LOGIC */
void endGame() {
  state = GAME_OVER;
  if (score > bestScores[difficulty]) {
    bestScores[difficulty] = score;
    prefs.putInt(BEST_KEYS[difficulty], score);
  }
  drawGameOver();
  beep(190, 150);
}

void spawnPiece() {
  current = {nextType, 0, 3, -1};
  nextType = takeFromBag();
  if (!canPlace(current.type, current.rotation, current.x, current.y)) {
    endGame();
  }
}

void clearFullLines() {
  int cleared = 0;
  for (int r = ROWS - 1; r >= 0; --r) {
    bool full = true;
    for (int c = 0; c < COLS; ++c) {
      if (board[r][c] == 0) { full = false; break; }
    }
    if (!full) continue;

    for (int copy = r; copy > 0; --copy) {
      memcpy(board[copy], board[copy - 1], COLS);
    }
    memset(board[0], 0, COLS);
    ++cleared;
    ++r; // This row now contains the former row above: check it again.
  }

  if (cleared > 0) {
    const int points[] = {0, 100, 300, 500, 800};
    score += points[cleared] * level;
    lines += cleared;
    level = 1 + lines / 10;
    beep(cleared == 4 ? 900 : 650, 90);
  }
}

void lockPiece() {
  bool aboveTop = false;
  for (int r = 0; r < 4; ++r) {
    for (int c = 0; c < 4; ++c) {
      if (!pieceCell(current.type, current.rotation, c, r)) continue;
      int x = current.x + c;
      int y = current.y + r;
      if (y < 0) aboveTop = true;
      else board[y][x] = 1 + current.type;
    }
  }

  if (aboveTop) { endGame(); return; }
  clearFullLines();
  spawnPiece();
}

bool movePiece(int dx, int dy) {
  if (!canPlace(current.type, current.rotation,
                current.x + dx, current.y + dy)) return false;
  current.x += dx;
  current.y += dy;
  return true;
}

void rotatePiece() {
  if (current.type == 1) return; // O piece is unchanged by rotation.
  int rotation = (current.rotation + 1) & 3;
  const int kicks[] = {0, -1, 1, -2, 2};
  for (int dx : kicks) {
    if (canPlace(current.type, rotation, current.x + dx, current.y)) {
      current.rotation = rotation;
      current.x += dx;
      beep(500, 17);
      return;
    }
  }
}

void hardDrop() {
  if (state != PLAYING) return;
  int distance = 0;
  while (movePiece(0, 1)) ++distance;
  score += 2 * distance;
  lockPiece();
  if (state == PLAYING) beep(260, 35);
}

void startGame() {
  memset(board, 0, sizeof(board));
  score = 0;
  lines = 0;
  level = 1;
  bagIndex = 7;
  nextType = takeFromBag();
  state = PLAYING;
  spawnPiece();
  uint32_t now = millis();
  lastGravityAt = now;
  lastSoftDropAt = now - 60;
  lastDrawAt = now;
  horizontalDirection = 0;
  upLatched = false;
  drawGameScreen();
  renderBoard();
  beep(620, 50);
}

void pauseGame() {
  if (state != PLAYING) return;
  state = PAUSED;
  drawPause();
  beep(380, 45);
}

void resumeGame() {
  if (state != PAUSED) return;
  state = PLAYING;
  lastGravityAt = millis();
  lastSoftDropAt = millis();
  horizontalDirection = 0;
  drawGameScreen();
  renderBoard();
  beep(620, 45);
}

/* JOYSTICK INPUT */
void updateMenu(uint32_t now) {
  float x = readAxis(JOY_X, centerX) * X_DIRECTION;
  int direction = (x > 0.55f) ? 1 : (x < -0.55f ? -1 : 0);
  if (direction != 0 &&
      (direction != lastMenuDirection || now - lastMenuMoveAt >= 350)) {
    difficulty = (difficulty + direction + 3) % 3;
    lastMenuMoveAt = now;
    beep(440, 25);
    drawMenu();
  }
  lastMenuDirection = direction;
}

void updatePlaying(uint32_t now) {
  float x = readAxis(JOY_X, centerX) * X_DIRECTION;
  float y = readAxis(JOY_Y, centerY) * Y_DIRECTION;

  int direction = (x > 0.55f) ? 1 : (x < -0.55f ? -1 : 0);
  if (direction == 0) {
    horizontalDirection = 0;
  } else if (direction != horizontalDirection) {
    movePiece(direction, 0);
    horizontalDirection = direction;
    nextHorizontalAt = now + 190; // Delay before auto-repeat.
  } else if ((int32_t)(now - nextHorizontalAt) >= 0) {
    movePiece(direction, 0);
    nextHorizontalAt = now + 80; // Speed while held.
  }

  if (y < -0.55f && !upLatched) {
    rotatePiece();
    upLatched = true;
  } else if (y > -0.30f) {
    upLatched = false;
  }

  if (y > 0.55f && now - lastSoftDropAt >= 55) {
    if (movePiece(0, 1)) {
      ++score; // One point per manually soft-dropped row.
    } else {
      lockPiece();
    }
    lastSoftDropAt = now;
    lastGravityAt = now;
  } else {
    int fallInterval = BASE_FALL_MS[difficulty] - (level - 1) * 55;
    if (fallInterval < 90) fallInterval = 90;
    if (now - lastGravityAt >= (uint32_t)fallInterval) {
      if (!movePiece(0, 1)) lockPiece();
      lastGravityAt = now;
    }
  }

  if (state == PLAYING && now - lastDrawAt >= 33) {
    renderBoard();
    lastDrawAt = now;
  }
}

// One debounced joystick switch: tap = action; hold = pause/menu.
void updateButton(uint32_t now) {
  bool rawPressed = (digitalRead(JOY_SW) == LOW);
  if (rawPressed != previousRawButton) buttonChangedAt = now;
  previousRawButton = rawPressed;

  if (now - buttonChangedAt >= 25 && rawPressed != stableButtonPressed) {
    stableButtonPressed = rawPressed;
    if (stableButtonPressed) {
      buttonPressedAt = now;
      longPressHandled = false;
      stateAtButtonPress = state;
    } else if (!longPressHandled && state == stateAtButtonPress) {
      switch (state) {
        case MENU: startGame(); break;
        case PLAYING: hardDrop(); break;
        case PAUSED: resumeGame(); break;
        case GAME_OVER: startGame(); break;
      }
    }
  }

  if (stableButtonPressed && !longPressHandled &&
      now - buttonPressedAt >= 700) {
    if (state == PLAYING) {
      longPressHandled = true;
      pauseGame();
    } else if (state == PAUSED || state == GAME_OVER) {
      longPressHandled = true;
      state = MENU;
      ::returnToLauncher();
    }
  }
}

// Scores remain in the original Tetris NVS namespace.
void initScores() {
  prefs.begin("tetrisGame", false);
  for (int i = 0; i < 3; ++i) {
    bestScores[i] = prefs.getInt(BEST_KEYS[i], 0);
  }
}

} // namespace Tetris
