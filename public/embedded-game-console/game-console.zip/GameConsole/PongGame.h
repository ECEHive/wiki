#pragma once
// Single-player Pong: player on left, computer on right.
namespace Pong {
Preferences prefs;
const char* const KEYS[3] = {"easy", "normal", "hard"};
int difficulty = 1;
int bestScores[3] = {0, 0, 0};
int playerScore = 0, aiScore = 0;
float playerY = 120, aiY = 120, ballX = 160, ballY = 120;
float vx = 150, vy = 75;
bool waitingToServe = true;
uint32_t lastFrame = 0;
constexpr int TOP = 30, PADDLE_H = 42, PADDLE_W = 7, BALL_R = 4;

void initScores() {
  prefs.begin("pongGame", false);
  for (int i = 0; i < 3; ++i) bestScores[i] = prefs.getInt(KEYS[i], 0);
}

void drawHud() {
  tft.fillRect(0, 0, 320, TOP, 0x0842);
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_CYAN);
  tft.setCursor(8, 7); tft.print("YOU:"); tft.print(playerScore);
  tft.setCursor(207, 7); tft.print("CPU:"); tft.print(aiScore);
  tft.drawFastHLine(0, TOP - 1, 320, ST77XX_BLUE);
}
void drawPaddle(int x, float y, uint16_t color) {
  tft.fillRect(x, (int)y - PADDLE_H / 2, PADDLE_W, PADDLE_H, color);
}
void drawCenterLine() {
  for (int y = TOP + 8; y < 240; y += 20)
    tft.drawFastVLine(159, y, 9, 0x39E7);
}
void drawAll() {
  tft.fillScreen(ST77XX_BLACK);
  drawHud(); drawCenterLine();
  drawPaddle(16, playerY, ST77XX_CYAN);
  drawPaddle(297, aiY, ST77XX_RED);
  tft.fillCircle((int)ballX, (int)ballY, BALL_R, ST77XX_WHITE);
  if (waitingToServe) centerText("TAP TO SERVE", 112, 2, ST77XX_YELLOW);
}
void resetBall(bool towardPlayer) {
  ballX = 160; ballY = 125;
  float speed = 145.0f + difficulty * 25.0f;
  vx = towardPlayer ? -speed : speed;
  vy = random(-80, 81);
  if (vy > -20 && vy < 20) vy = 48;
  waitingToServe = true;
}
void startGame() {
  playerScore = 0; aiScore = 0;
  playerY = 125; aiY = 125;
  resetBall(false);
  lastFrame = millis();
  drawAll(); beep(620, 40);
}
void serve() {
  if (waitingToServe) {
    waitingToServe = false;
    drawAll();
    beep(550, 25);
  }
}
void endGame() {
  if (playerScore > bestScores[difficulty]) {
    bestScores[difficulty] = playerScore;
    prefs.putInt(KEYS[difficulty], playerScore);
  }
  arcadePhase = ARCADE_GAME_OVER;
  drawArcadeGameOver("PONG", playerScore, bestScores[difficulty]);
  beep(playerScore >= 7 ? 780 : 180, 120);
}
void resume(uint32_t now) {
  lastFrame = now;
  drawAll();
}
void update(uint32_t now) {
  if (now - lastFrame < 33) return;
  float dt = (now - lastFrame) / 1000.0f;
  if (dt > 0.05f) dt = 0.05f;
  lastFrame = now;
  // Erase only moving shapes, avoiding full-screen redraw flicker.
  drawPaddle(16, playerY, ST77XX_BLACK);
  drawPaddle(297, aiY, ST77XX_BLACK);
  tft.fillCircle((int)ballX, (int)ballY, BALL_R + 1, ST77XX_BLACK);
  float axis = readAxis(JOY_Y, centerY) * Y_DIRECTION;
  playerY += axis * 205.0f * dt;
  if (playerY < TOP + PADDLE_H / 2 + 2) playerY = TOP + PADDLE_H / 2 + 2;
  if (playerY > 239 - PADDLE_H / 2) playerY = 239 - PADDLE_H / 2;
  float target = ballY;
  float maxStep = (difficulty == 0 ? 83.0f : difficulty == 1 ? 135.0f : 185.0f) * dt;
  float gap = target - aiY;
  if (gap > maxStep) gap = maxStep;
  if (gap < -maxStep) gap = -maxStep;
  aiY += gap;
  if (aiY < TOP + PADDLE_H / 2 + 2) aiY = TOP + PADDLE_H / 2 + 2;
  if (aiY > 239 - PADDLE_H / 2) aiY = 239 - PADDLE_H / 2;
  if (!waitingToServe) {
    ballX += vx * dt; ballY += vy * dt;
    if (ballY < TOP + BALL_R + 1) {
      ballY = TOP + BALL_R + 1; vy = fabsf(vy); beep(280, 12);
    } else if (ballY > 239 - BALL_R) {
      ballY = 239 - BALL_R; vy = -fabsf(vy); beep(280, 12);
    }
    if (vx < 0 && ballX - BALL_R <= 16 + PADDLE_W && ballX > 10 &&
        fabsf(ballY - playerY) < PADDLE_H / 2 + BALL_R) {
      ballX = 16 + PADDLE_W + BALL_R;
      vx = fminf(290.0f, fabsf(vx) * 1.055f);
      vy = (ballY - playerY) * 5.0f;
      beep(620, 18);
    }
    if (vx > 0 && ballX + BALL_R >= 297 && ballX < 308 &&
        fabsf(ballY - aiY) < PADDLE_H / 2 + BALL_R) {
      ballX = 297 - BALL_R;
      vx = -fminf(290.0f, fabsf(vx) * 1.055f);
      vy = (ballY - aiY) * 5.0f;
      beep(420, 18);
    }
    if (ballX < -BALL_R || ballX > 320 + BALL_R) {
      bool youScored = ballX > 320;
      if (youScored) ++playerScore; else ++aiScore;
      if (playerScore >= 7 || aiScore >= 7) { endGame(); return; }
      resetBall(youScored);
      drawAll();
      return;
    }
  }
  // Restore center dots wherever moving shapes previously erased them.
  drawCenterLine();
  drawPaddle(16, playerY, ST77XX_CYAN);
  drawPaddle(297, aiY, ST77XX_RED);
  tft.fillCircle((int)ballX, (int)ballY, BALL_R, ST77XX_WHITE);
}
} // namespace Pong
