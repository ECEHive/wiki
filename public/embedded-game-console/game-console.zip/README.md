# Game Console Workshop

Extract the ZIP before opening a sketch in Arduino IDE. Open the `.ino` inside
the folder with the same name. Each folder is a separate project:

- `WiringTest/WiringTest.ino`: check the screen, joystick, and buzzer first.
- `TargetPractice/TargetPractice.ino`: activity starter; replace the `?`
  placeholders before compiling.
- `TargetPracticeComplete/TargetPracticeComplete.ino`: activity answers.
- `GameConsole/GameConsole.ino`: seven-game console; keep all accompanying `.h` files in
  this folder with the sketch.

Individual downloads contain only the selected project. The all-code ZIP
contains all four sketch folders. Do not combine the sketches into one folder.

## Setup

Select your ESP32-C6 board (ESP32C6 Dev Module for the workshop) and USB port.
Install `esp32 by Espressif Systems` version 3.x in Boards Manager. Install
`Adafruit GFX Library` and `Adafruit ST7735 and ST7789 Library`, including their
dependencies, from Library Manager. SPI and Preferences come with the ESP32 core.

Keep the joystick centered at startup for calibration. Use Serial Monitor at
115200 baud with the wiring test.

## GPIO wiring

| Connection | GPIO |
| --- | --- |
| TFT CS | 4 |
| TFT DC | 5 |
| TFT SCLK | 7 |
| TFT MOSI | 6 |
| Joystick X | 0 |
| Joystick Y | 1 |
| Joystick switch | 10 (internal pull-up; switch to GND) |
| Buzzer | 11 |

TFT reset is wired high (`TFT_RST = -1`). Follow the workshop slides for power,
ground, and backlight wiring.

Change `X_DIRECTION` or `Y_DIRECTION` to `-1` if motion is reversed. Change
`SCREEN_ROTATION` from `1` to `3` if the screen is upside down.

Full workshop guide and slides:
https://wiki.hivemakerspace.com/projects/embedded-game-console/
