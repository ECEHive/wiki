#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>

// ---------- WIRING ----------
const int TFT_CS   = 4;
const int TFT_DC   = 5;
const int TFT_SCLK = 7;
const int TFT_MOSI = 6;
const int TFT_RST  = -1;   // RST wired high on module

const int JOY_X  = 0;
const int JOY_Y  = 1;
const int JOY_SW = 10;

const int BUZZER = 11;

// Change to -1 if a direction is backwards
const int X_DIRECTION = 1;
const int Y_DIRECTION = 1;

// ---------- DISPLAY ----------
const int NATIVE_WIDTH  = 240;
const int NATIVE_HEIGHT = 320;
const int SCREEN_ROTATION = 1;   // landscape
const int SCREEN_WIDTH  = 320;
const int SCREEN_HEIGHT = 240;

// ---------- JOYSTICK ----------
const int JOYSTICK_THRESHOLD = 600;
const int MOVE_SPEED = 4;
const int DOT_RADIUS = 5;

// ---------- BUZZER ----------
const int BUZZER_START_FREQ = 2000;
const int BUZZER_BITS = 8;

Adafruit_ST7789 tft(TFT_CS, TFT_DC, TFT_RST);

int centerX = 0;
int centerY = 0;

int dotX = SCREEN_WIDTH / 2;
int dotY = SCREEN_HEIGHT / 2;
int oldDotX = dotX;
int oldDotY = dotY;

bool lastPressed = false;

void beep(int freq, int timeMs) {
  ledcWriteTone(BUZZER, freq);
  delay(timeMs);
  ledcWriteTone(BUZZER, 0);
}

void drawDot(int x, int y, uint16_t color) {
  tft.fillCircle(x, y, DOT_RADIUS, color);
}

void drawLabels() {
  tft.fillScreen(ST77XX_BLACK);

  tft.setTextColor(ST77XX_WHITE);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("WIRING TEST");

  tft.setTextSize(1);
  tft.setCursor(10, 40);
  tft.print("Move joystick: dot should move");

  tft.setCursor(10, 55);
  tft.print("Press joystick: buzzer should beep");

  tft.setCursor(10, 80);
  tft.print("X:");

  tft.setCursor(10, 100);
  tft.print("Y:");

  tft.setCursor(10, 120);
  tft.print("SW:");

  tft.setCursor(10, 220);
  tft.print("If the screen, dot, and sound work, wiring is good.");
}

void updateReadings(int xRaw, int yRaw, bool pressed) {
  tft.fillRect(40, 78, 100, 18, ST77XX_BLACK);
  tft.fillRect(40, 98, 100, 18, ST77XX_BLACK);
  tft.fillRect(40, 118, 100, 18, ST77XX_BLACK);

  tft.setTextColor(ST77XX_CYAN);
  tft.setTextSize(2);

  tft.setCursor(40, 80);
  tft.print(xRaw);

  tft.setCursor(40, 100);
  tft.print(yRaw);

  tft.setCursor(40, 120);
  if (pressed) tft.print("PRESSED");
  else         tft.print("RELEASED");
}

void setup() {
  Serial.begin(115200);

  pinMode(JOY_X, INPUT);
  pinMode(JOY_Y, INPUT);
  pinMode(JOY_SW, INPUT_PULLUP);

  ledcAttach(BUZZER, BUZZER_START_FREQ, BUZZER_BITS);
  ledcWriteTone(BUZZER, 0);

  SPI.begin(TFT_SCLK, -1, TFT_MOSI, TFT_CS);

  tft.init(NATIVE_WIDTH, NATIVE_HEIGHT);
  tft.setRotation(SCREEN_ROTATION);

  // Quick TFT test
  tft.fillScreen(ST77XX_RED);
  delay(300);
  tft.fillScreen(ST77XX_GREEN);
  delay(300);
  tft.fillScreen(ST77XX_BLUE);
  delay(300);
  tft.fillScreen(ST77XX_BLACK);
  delay(200);

  // Calibrate joystick center
  centerX = analogRead(JOY_X);
  centerY = analogRead(JOY_Y);

  drawLabels();
  drawDot(dotX, dotY, ST77XX_WHITE);

  // Startup beep
  beep(800, 100);
}

void loop() {
  int xRaw = analogRead(JOY_X);
  int yRaw = analogRead(JOY_Y);
  bool pressed = (digitalRead(JOY_SW) == LOW);

  int x = xRaw - centerX;
  int y = yRaw - centerY;

  oldDotX = dotX;
  oldDotY = dotY;

  if (x > JOYSTICK_THRESHOLD)  dotX += MOVE_SPEED * X_DIRECTION;
  if (x < -JOYSTICK_THRESHOLD) dotX -= MOVE_SPEED * X_DIRECTION;
  if (y > JOYSTICK_THRESHOLD)  dotY += MOVE_SPEED * Y_DIRECTION;
  if (y < -JOYSTICK_THRESHOLD) dotY -= MOVE_SPEED * Y_DIRECTION;

  dotX = constrain(dotX, DOT_RADIUS, SCREEN_WIDTH - DOT_RADIUS);
  dotY = constrain(dotY, 145, SCREEN_HEIGHT - DOT_RADIUS);

  if (dotX != oldDotX || dotY != oldDotY) {
    drawDot(oldDotX, oldDotY, ST77XX_BLACK);
    drawDot(dotX, dotY, ST77XX_WHITE);
  }

  updateReadings(xRaw, yRaw, pressed);

  if (pressed && !lastPressed) {
    tft.drawRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, ST77XX_YELLOW);
    beep(1000, 120);
    tft.drawRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, ST77XX_BLACK);
  }

  lastPressed = pressed;

  Serial.print("X: ");
  Serial.print(xRaw);
  Serial.print("  Y: ");
  Serial.print(yRaw);
  Serial.print("  SW: ");
  Serial.println(pressed ? "PRESSED" : "RELEASED");

  delay(25);
}
