/* 
  TARGET PRACTICE: move the joystick to hit the target!
  Challenge 1: Joystick
  Challenge 2: Buzzer
  Challenge 3: Screen
*/

#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>

// wiring 
const int TFT_CS = 4, TFT_DC = 5, TFT_SCLK = 7, TFT_MOSI = 6;
const int TFT_RST = -1; // reset + backlight wired high
const int JOY_X = 0, JOY_Y = 1, JOY_SW = 10;
const int BUZZER = 11;
const int X_DIRECTION = 1, Y_DIRECTION = 1; // change to -1 if reversed

// display and game constants
const int NATIVE_WIDTH = 240, NATIVE_HEIGHT = 320;
const int SCREEN_ROTATION = 1;  // landscape
const int SCREEN_WIDTH = 320, SCREEN_HEIGHT = 240;
const int SCORE_BAR_HEIGHT = 32;
const int SCORE_TEXT_X = 10, SCORE_TEXT_Y = 8, SCORE_TEXT_SIZE = 2;
const int TARGET_RADIUS = 20, INNER_RADIUS = 12, CENTER_RADIUS = 5;
const int AIM_SIZE = 10; // in each of the 4 directions
const int SCREEN_MARGIN = 2;
const int JOYSTICK_THRESHOLD = 650;
const int MOVE_SPEED = 4;           // Pixels moved per update
const int FRAME_DELAY_MS = 25;
const int STARTUP_DELAY_MS = 100;

// buzzer settings
const int BUZZER_START_FREQ = 2000, BUZZER_BITS = 8;
const int HAPPY_NOTE_1 = 660, HAPPY_NOTE_2 = 990;
const int HAPPY_TIME_1 = 80, HAPPY_TIME_2 = 120;
const int SAD_NOTE_1 = 330, SAD_NOTE_2 = 220;
const int SAD_TIME_1 = 130, SAD_TIME_2 = 160;

// game variables
// 3a. Initialize screen variable
Adafruit_ST7789 tft(?, ?, ?);
int aimX = SCREEN_WIDTH / 2, aimY = SCREEN_HEIGHT / 2;
int targetX, targetY;
int centerX, centerY;
int score = 0;
bool wasPressed = false;

void newTarget() {
  targetX = random(TARGET_RADIUS + SCREEN_MARGIN,
                   SCREEN_WIDTH - TARGET_RADIUS - SCREEN_MARGIN);
  targetY = random(SCORE_BAR_HEIGHT + TARGET_RADIUS + SCREEN_MARGIN,
                   SCREEN_HEIGHT - TARGET_RADIUS - SCREEN_MARGIN);
}

void drawTarget() {
  // 3c. Draw the target in the right place!
  tft.fillCircle(targetX, targetY, TARGET_RADIUS, ST77XX_RED);
  tft.fillCircle(?, ?, INNER_RADIUS, ST77XX_WHITE);
  tft.fillCircle(?, ?, CENTER_RADIUS, ST77XX_YELLOW);
}

void drawAim(int x, int y, uint16_t color) {
  tft.drawFastHLine(x - AIM_SIZE, y, 2 * AIM_SIZE + 1, color);
  tft.drawFastVLine(x, y - AIM_SIZE, 2 * AIM_SIZE + 1, color);
}

void showScore() {
  tft.fillRect(0, 0, SCREEN_WIDTH, SCORE_BAR_HEIGHT, ST77XX_BLACK);
  tft.setCursor(SCORE_TEXT_X, SCORE_TEXT_Y);
  tft.setTextColor(ST77XX_WHITE);
  tft.setTextSize(SCORE_TEXT_SIZE);
  tft.print("SCORE: ");
  tft.print(score);
}

// 2b. Buzzer happy sound: play two notes (low then high), then stop. 
void happySound() {
  ledcWriteTone(?, ?);
  delay(?);
  ledcWriteTone(?, ?);
  delay(?);
  ledcWriteTone(?, ?);
}

void sadSound() {
  ledcWriteTone(BUZZER, SAD_NOTE_1);
  delay(SAD_TIME_1);
  ledcWriteTone(BUZZER, SAD_NOTE_2);
  delay(SAD_TIME_2);
  ledcWriteTone(BUZZER, 0);
}

void setup() {
  // 1a. Joystick setup
  pinMode(JOY_X, ?);
  pinMode(JOY_Y, ?);
  pinMode(JOY_SW, ?);

  // 1b. Joystick calibration
  // calibrate joystick center
  delay(STARTUP_DELAY_MS);
  centerX = analogRead(?);
  centerY = analogRead(?);

  // 2a. Buzzer setup 
  ledcAttach(BUZZER, ?, ?);
  ledcWriteTone(BUZZER, ?); // what frequency stops the buzzer? 

  // 3b. Screen setup
  SPI.begin(?, -1, ?, ?);
  tft.init(?, ?);
  tft.setRotation(?);
  tft.fillScreen(?); // clear the screen to black

  randomSeed(micros());
  newTarget();
  showScore();
  drawTarget();
  drawAim(aimX, aimY, ST77XX_CYAN);
}

void loop() {
  int oldX = aimX, oldY = aimY;
  // 1c. Read joystick input
  int x = analogRead(?) - centerX;
  int y = analogRead(?) - centerY;

  if (x > JOYSTICK_THRESHOLD) aimX += MOVE_SPEED * X_DIRECTION;
  if (x < -JOYSTICK_THRESHOLD) aimX -= MOVE_SPEED * X_DIRECTION;
  if (y > JOYSTICK_THRESHOLD) aimY += MOVE_SPEED * Y_DIRECTION;
  if (y < -JOYSTICK_THRESHOLD) aimY -= MOVE_SPEED * Y_DIRECTION;

  aimX = constrain(aimX, AIM_SIZE + SCREEN_MARGIN,
                   SCREEN_WIDTH - AIM_SIZE - SCREEN_MARGIN);
  aimY = constrain(aimY, SCORE_BAR_HEIGHT + AIM_SIZE + SCREEN_MARGIN,
                   SCREEN_HEIGHT - AIM_SIZE - SCREEN_MARGIN);

  if (aimX != oldX || aimY != oldY) {
    drawAim(oldX, oldY, ST77XX_BLACK);

    // redraw target if it was erased by the old crosshair.
    if (abs(oldX - targetX) <= TARGET_RADIUS + AIM_SIZE &&
        abs(oldY - targetY) <= TARGET_RADIUS + AIM_SIZE) {
      drawTarget();
    }
    drawAim(aimX, aimY, ST77XX_CYAN);
  }

  bool pressed = digitalRead(JOY_SW) == LOW;
  if (pressed && !wasPressed) {
    int dx = aimX - targetX;
    int dy = aimY - targetY;

    if (dx * dx + dy * dy <= TARGET_RADIUS * TARGET_RADIUS) {
      drawAim(aimX, aimY, ST77XX_BLACK);
      tft.fillCircle(targetX, targetY, TARGET_RADIUS + SCREEN_MARGIN,
                     ST77XX_BLACK);
      score++;
      showScore();
      newTarget();
      drawTarget();
      drawAim(aimX, aimY, ST77XX_CYAN);
      happySound();
    } else {
      sadSound();
    }
  }
  wasPressed = pressed;
  delay(FRAME_DELAY_MS);
}

